using System.Runtime.InteropServices;
using System.Text;

namespace SerialBridgeConsole;

/// <summary>Кусок строки состояния своим цветом.</summary>
readonly record struct Segment(string Text, ConsoleColor Color);

/// <summary>
/// Консоль с отдельной строкой ввода внизу. Вывод МК печатается выше неё,
/// поэтому текст, который печатает скетч, не перемешивается с набираемым.
/// Все обращения к Console идут под одной блокировкой.
/// </summary>
sealed class Terminal
{
    const string Prompt = "> ";

    readonly object _sync = new();
    readonly bool _vt;
    readonly StringBuilder _input = new();
    readonly List<string> _history = new();
    int _historyPos;
    int _cursor;          // позиция курсора в набираемой строке
    int _viewStart;       // с какого символа строка видна (длинная строка прокручивается)
    int _inputTop;        // строка экрана со строкой ввода
    int _footerTop;       // первая строка «подвала»: панель состояния (если есть) и строка ввода
    IReadOnlyList<Segment>? _status;   // панель над строкой ввода (напряжения)
    int _outRow, _outCol; // где продолжать вывод МК
    bool _atLineStart = true;
    bool _closed;         // после Shutdown ничего не выводим

    public bool Timestamps { get; set; }

    public Terminal()
    {
        _vt = VirtualTerminal.TryEnable();
        lock (_sync)
        {
            if (Console.CursorLeft != 0) Console.Write("\r\n");
            PadToWindowBottom();
            _outRow = Console.CursorTop;
            _outCol = 0;
            DrawFooterFresh();
        }
    }

    /// <summary>
    /// Опустить курсор к нижней строке окна пустыми строками. Тогда панель и строка ввода
    /// с самого начала стоят внизу, а вывод прокручивается над ними и не сдвигает их.
    /// </summary>
    static void PadToWindowBottom()
    {
        try
        {
            int bottom = Console.WindowTop + Console.WindowHeight - 1;
            for (int row = Console.CursorTop; row < bottom; row++) Console.Write("\r\n");
        }
        catch (IOException) { }
        catch (ArgumentOutOfRangeException) { }
    }

    public static int Width => Math.Max(20, Math.Min(Console.BufferWidth, Console.WindowWidth));

    // ------------------------------------------------------------------ вывод

    /// <summary>Текст от МК: продолжает текущую строку, переводы строк — как пришли.</summary>
    public void WriteMcu(string text)
    {
        lock (_sync) Guarded(() =>
        {
            if (_closed) return;
            BeginOutput();
            WriteMcuText(text);
            EndOutput();
        });
    }

    /// <summary>Отдельная строка (служебное сообщение, эхо отправленного, hex-дамп).</summary>
    public void Line(string text, ConsoleColor color)
    {
        lock (_sync) Guarded(() =>
        {
            if (_closed) return;
            BeginOutput();
            if (_outCol != 0) Console.Write("\r\n");   // незаконченную строку МК переносим
            Console.ForegroundColor = color;
            Console.Write(text);
            Console.ResetColor();
            Console.Write("\r\n");
            _atLineStart = true;
            EndOutput();
        });
    }

    public void Info(string text) => Line(text, ConsoleColor.Yellow);
    public void Warn(string text) => Line(text, ConsoleColor.Red);
    public void Echo(string text) => Line("» " + text, ConsoleColor.Cyan);

    public void Clear()
    {
        lock (_sync)
        {
            Console.Clear();
            PadToWindowBottom();
            _outRow = Console.CursorTop;
            _outCol = 0;
            _atLineStart = true;
            DrawFooterFresh();
        }
    }

    /// <summary>Убрать строку ввода перед выходом из программы.</summary>
    public void Shutdown()
    {
        lock (_sync)
        {
            if (_closed) return;
            _closed = true;
            ClearFooter();
            Console.SetCursorPosition(_outCol, _outRow);
            if (_outCol != 0) Console.Write("\r\n");
            Console.ResetColor();
            TrySetCursorVisible(true);
        }
    }

    /// <summary>
    /// Если окно консоли изменили и запомненные координаты вышли за буфер —
    /// начинаем с текущей позиции, а не падаем.
    /// </summary>
    void Guarded(Action action)
    {
        try
        {
            action();
        }
        catch (ArgumentOutOfRangeException)
        {
            try
            {
                Console.ResetColor();
                if (Console.CursorLeft != 0) Console.Write("\r\n");
                _outRow = Console.CursorTop;
                _outCol = 0;
                _atLineStart = true;
                DrawFooterFresh();
                TrySetCursorVisible(true);
            }
            catch (ArgumentOutOfRangeException) { }
        }
    }

    void BeginOutput()
    {
        TrySetCursorVisible(false);
        ClearFooter();
        Console.SetCursorPosition(_outCol, _outRow);
    }

    void ClearFooter()
    {
        for (int row = _footerTop; row <= _inputTop; row++)
        {
            Console.SetCursorPosition(0, row);
            ClearToEol();
        }
    }

    void EndOutput()
    {
        _outCol = Console.CursorLeft;
        _outRow = Console.CursorTop;
        DrawFooterFresh();
        TrySetCursorVisible(true);
    }

    void WriteMcuText(string text)
    {
        var sb = new StringBuilder(text.Length);
        Console.ForegroundColor = ConsoleColor.Gray;
        foreach (char c in text)
        {
            if (c == '\r') continue;                       // \r\n от println → один перевод строки
            if (c == '\n')
            {
                Flush(sb);
                Console.Write("\r\n");
                _atLineStart = true;
                continue;
            }
            if (char.IsControl(c) && c != '\t') continue;  // прочие управляющие символы не печатаем
            if (_atLineStart)
            {
                _atLineStart = false;
                if (Timestamps)
                {
                    Flush(sb);
                    Console.ForegroundColor = ConsoleColor.DarkGray;
                    Console.Write(DateTime.Now.ToString("[HH:mm:ss.fff] "));
                    Console.ForegroundColor = ConsoleColor.Gray;
                }
            }
            sb.Append(c);
        }
        Flush(sb);
        Console.ResetColor();
    }

    static void Flush(StringBuilder sb)
    {
        if (sb.Length == 0) return;
        Console.Write(sb.ToString());
        sb.Clear();
    }

    /// <summary>
    /// Нарисовать «подвал» под выводом: панель состояния (если есть) и строку ввода.
    /// Если последняя строка МК не закончена, подвал начинается строкой ниже.
    /// Координаты пересчитываются по итоговому положению курсора — с учётом прокрутки.
    /// </summary>
    void DrawFooterFresh()
    {
        Console.SetCursorPosition(_outCol, _outRow);
        bool lineBreak = _outCol != 0;
        if (lineBreak) Console.Write("\r\n");
        if (_status != null)
        {
            DrawStatusLine();
            Console.Write("\r\n");
        }
        _inputTop = Console.CursorTop;
        _footerTop = _status != null ? _inputTop - 1 : _inputTop;
        _outRow = lineBreak ? _footerTop - 1 : _footerTop;
        RedrawInput();
    }

    /// <summary>Строка состояния с текущей позиции (столбец 0), не длиннее ширины окна.</summary>
    void DrawStatusLine()
    {
        int left = Width - 1;
        foreach (Segment seg in _status!)
        {
            if (left <= 0) break;
            string t = seg.Text.Length > left ? seg.Text[..left] : seg.Text;
            Console.ForegroundColor = seg.Color;
            Console.Write(t);
            left -= t.Length;
        }
        Console.ResetColor();
        ClearToEol();
    }

    /// <summary>Показать, обновить (на месте) или убрать (null) панель над строкой ввода.</summary>
    public void SetStatus(IReadOnlyList<Segment>? status)
    {
        lock (_sync) Guarded(() =>
        {
            if (_closed) return;
            if ((_status == null) != (status == null))
            {
                BeginOutput();          // стираем подвал в старой раскладке
                _status = status;
                EndOutput();            // рисуем в новой
                return;
            }
            if (status == null) return;
            _status = status;
            TrySetCursorVisible(false);
            Console.SetCursorPosition(0, _footerTop);
            DrawStatusLine();
            Console.SetCursorPosition(Prompt.Length + _cursor - _viewStart, _inputTop);
            TrySetCursorVisible(true);
        });
    }

    void RedrawInput()
    {
        int avail = Math.Max(5, Width - Prompt.Length - 1);   // строка ввода никогда не переносится
        if (_cursor < _viewStart) _viewStart = _cursor;
        if (_cursor - _viewStart > avail) _viewStart = _cursor - avail;
        if (_viewStart > 0 && _input.Length - _viewStart < avail) _viewStart = Math.Max(0, _input.Length - avail);
        string visible = _input.ToString(_viewStart, Math.Min(avail, _input.Length - _viewStart));

        Console.SetCursorPosition(0, _inputTop);
        Console.ForegroundColor = ConsoleColor.Green;
        Console.Write(Prompt);
        Console.ResetColor();
        Console.Write(visible);
        ClearToEol();
        Console.SetCursorPosition(Prompt.Length + _cursor - _viewStart, _inputTop);
    }

    void ClearToEol()
    {
        if (_vt)
        {
            Console.Write("\x1b[K");
            return;
        }
        int left = Console.CursorLeft, top = Console.CursorTop;
        int n = Width - left - 1;
        if (n > 0) Console.Write(new string(' ', n));
        Console.SetCursorPosition(left, top);
    }

    static void TrySetCursorVisible(bool visible)
    {
        try { Console.CursorVisible = visible; } catch { }
    }

    // ------------------------------------------------------------------ ввод

    /// <summary>Прочитать строку с редактированием. null — пользователь нажал Ctrl+C.</summary>
    public string? ReadLine()
    {
        while (true)
        {
            ConsoleKeyInfo k = Console.ReadKey(intercept: true);
            lock (_sync)
            {
                if ((k.Modifiers & ConsoleModifiers.Control) != 0 && k.Key == ConsoleKey.C) return null;

                switch (k.Key)
                {
                    case ConsoleKey.Enter:
                        string line = _input.ToString();
                        if (line.Length > 0 && (_history.Count == 0 || _history[^1] != line)) _history.Add(line);
                        _historyPos = _history.Count;
                        _input.Clear();
                        _cursor = 0;
                        _viewStart = 0;
                        Guarded(RedrawInput);
                        return line;
                    case ConsoleKey.Backspace:
                        if (_cursor > 0) { _input.Remove(_cursor - 1, 1); _cursor--; }
                        break;
                    case ConsoleKey.Delete:
                        if (_cursor < _input.Length) _input.Remove(_cursor, 1);
                        break;
                    case ConsoleKey.LeftArrow:
                        if (_cursor > 0) _cursor--;
                        break;
                    case ConsoleKey.RightArrow:
                        if (_cursor < _input.Length) _cursor++;
                        break;
                    case ConsoleKey.Home:
                        _cursor = 0;
                        break;
                    case ConsoleKey.End:
                        _cursor = _input.Length;
                        break;
                    case ConsoleKey.Escape:
                        SetInput("");
                        break;
                    case ConsoleKey.UpArrow:
                        if (_historyPos > 0) SetInput(_history[--_historyPos]);
                        break;
                    case ConsoleKey.DownArrow:
                        if (_historyPos < _history.Count - 1) SetInput(_history[++_historyPos]);
                        else { _historyPos = _history.Count; SetInput(""); }
                        break;
                    default:
                        if (k.KeyChar != '\0' && !char.IsControl(k.KeyChar))
                        {
                            _input.Insert(_cursor, k.KeyChar);
                            _cursor++;
                        }
                        break;
                }
                Guarded(RedrawInput);
            }
        }
    }

    void SetInput(string s)
    {
        _input.Clear().Append(s);
        _cursor = s.Length;
    }
}

/// <summary>Включение обработки ESC-последовательностей в консоли Windows 10.</summary>
static class VirtualTerminal
{
    const int STD_OUTPUT_HANDLE = -11;
    const uint ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x0004;

    [DllImport("kernel32.dll", SetLastError = true)]
    static extern IntPtr GetStdHandle(int nStdHandle);

    [DllImport("kernel32.dll", SetLastError = true)]
    static extern bool GetConsoleMode(IntPtr hConsoleHandle, out uint lpMode);

    [DllImport("kernel32.dll", SetLastError = true)]
    static extern bool SetConsoleMode(IntPtr hConsoleHandle, uint dwMode);

    public static bool TryEnable()
    {
        if (!OperatingSystem.IsWindows()) return true;
        try
        {
            IntPtr h = GetStdHandle(STD_OUTPUT_HANDLE);
            if (!GetConsoleMode(h, out uint mode)) return false;
            if ((mode & ENABLE_VIRTUAL_TERMINAL_PROCESSING) != 0) return true;
            return SetConsoleMode(h, mode | ENABLE_VIRTUAL_TERMINAL_PROCESSING);
        }
        catch
        {
            return false;
        }
    }
}
