/*
  NanoTest — проверка беспроводного моста на Arduino Nano.

  Раз в 2 секунды печатает счётчик и напряжение на A0.
  Принимает строки из консоли на ПК (окончание строки — LF, как в консоли по умолчанию):
    stop / start     — остановить / возобновить вывод счётчика
    led on / led off — светодиод на D13
    любая другая строка — возвращается обратно («эхо»)

  Скорость должна совпадать со скоростью моста (по умолчанию 115200, меняется :baud).
  Прошивать Nano по USB можно, не отключая мост: пока из консоли ничего
  не отправляется, на D17 единица, канал модуля уровней в покое и загрузчику не мешает.
*/

const unsigned long BAUD = 115200;

char line[64];
uint8_t lineLen = 0;
unsigned long lastReport = 0;
bool reporting = true;                  // выводить счётчик (команды stop / start)
unsigned long counter = 0;

void setup() {
  Serial.begin(BAUD);
  pinMode(LED_BUILTIN, OUTPUT);
  Serial.println(F("NanoTest: старт. Команды: stop, start, led on, led off"));
}

void handleLine(const char *s) {
  if (strcmp(s, "stop") == 0) {
    reporting = false;
    Serial.println(F("Счётчик остановлен (start — продолжить)"));
  } else if (strcmp(s, "start") == 0) {
    reporting = true;
    lastReport = millis() - 2000;         // следующее показание — сразу
    Serial.println(F("Счётчик продолжает"));
  } else if (strcmp(s, "led on") == 0) {
    digitalWrite(LED_BUILTIN, HIGH);
    Serial.println(F("Светодиод включён"));
  } else if (strcmp(s, "led off") == 0) {
    digitalWrite(LED_BUILTIN, LOW);
    Serial.println(F("Светодиод выключен"));
  } else {
    Serial.print(F("Получено: "));
    Serial.println(s);
  }
}

void loop() {
  // Приём строки без блокировки: символы копятся до '\n'
  while (Serial.available() > 0) {
    char c = Serial.read();
    if (c == '\r') continue;
    if (c == '\n') {
      line[lineLen] = '\0';
      handleLine(line);
      lineLen = 0;
    } else if (lineLen < sizeof(line) - 1) {
      line[lineLen++] = c;
    }
  }

  if (reporting && millis() - lastReport >= 2000) {
    lastReport = millis();
    int raw = analogRead(A0);
    Serial.print(F("Счётчик: "));
    Serial.print(++counter);
    Serial.print(F(", A0 = "));
    Serial.print(raw * 5.0 / 1023.0, 2);
    Serial.println(F(" В"));
  }
}
