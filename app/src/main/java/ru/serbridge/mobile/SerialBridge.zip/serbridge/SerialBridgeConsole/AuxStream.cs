using System.Net.Sockets;
using System.Text;

namespace SerialBridgeConsole;

/// <summary>
/// Второй поток моста: линия XP2.6 как приёмник UART («:aux uart 256000»), порт 2327, только чтение.
/// Показ: auto (радар LD2410 узнаётся сам, остальное — текстом или hex), text, hex, ld2410, off.
/// Строки выводятся с пометкой «AUX›» своим цветом; состояние радара — на панели над строкой ввода.
/// </summary>
sealed class AuxStream
{
    public const int DefaultPort = 2327;
    public static readonly string[] Modes = { "auto", "text", "hex", "ld2410", "off" };

    readonly Terminal _ui;
    readonly Func<string?> _host;
    readonly Action<string> _log;            // строка в журнал сеанса
    readonly object _lock = new();
    TcpClient? _tcp;

    // ---- показ (под _lock)
    string _mode = "auto";
    int _ldPeriodSec;
    readonly Ld2410 _ld = new();
    Ld2410.Report? _last;
    DateTime _lastReport = DateTime.MinValue;
    bool _ldAnnounced, _noFramesWarned;
    DateTime _lastLdLine = DateTime.MinValue;
    int _prevPresence = -1;
    string? _panelKey;
    long _bytesSinceFrame, _rxBytes;
    readonly StringBuilder _partial = new();
    readonly Decoder _utf8 = Encoding.UTF8.GetDecoder();
    readonly char[] _chars = new char[4200];
    DateTime _partialAt;

    enum Kind { Raw, Info, Good, Warn }

    public AuxStream(Terminal ui, Func<string?> host, Action<string> log)
    {
        _ui = ui;
        _host = host;
        _log = log;
    }

    /// <summary>Вызывается при изменении состояния радара — перерисовать панель.</summary>
    public Action? PanelChanged;

    // ============================================================ сеть

    public async Task RunAsync(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            string? host = _host();
            if (host == null)
            {
                if (!await Pause(1000, ct)) break;
                continue;
            }
            bool wasUp = false;
            try
            {
                using var tcp = new TcpClient { NoDelay = true };
                Bridge.ConfigureKeepAlive(tcp.Client);
                using (var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct))
                {
                    timeout.CancelAfter(4000);
                    await tcp.ConnectAsync(host, DefaultPort, timeout.Token);
                }
                lock (_lock) _tcp = tcp;
                wasUp = true;
                NetworkStream stream = tcp.GetStream();
                var buf = new byte[2048];
                while (_host() == host)
                {
                    int n = await stream.ReadAsync(buf, ct);
                    if (n == 0) break;
                    var chunk = new byte[n];
                    Buffer.BlockCopy(buf, 0, chunk, 0, n);
                    Feed(chunk);
                }
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested)
            {
                break;
            }
            catch (Exception)
            {
                // нет связи или старая прошивка без порта 2327 — тихо пробуем позже
            }
            finally
            {
                lock (_lock)
                {
                    _tcp = null;
                    if (wasUp)
                    {
                        FlushPartial();
                        _utf8.Reset();
                        _ld.Reset();
                        _prevPresence = -1;
                    }
                }
            }
            if (!await Pause(wasUp ? 2000 : 5000, ct)) break;
        }
    }

    /// <summary>Раз в 250 мс: дописать строку, которой давно не приходит конец; обновить панель.</summary>
    public async Task WatchAsync(CancellationToken ct)
    {
        while (await Pause(250, ct))
        {
            lock (_lock)
            {
                if (_partial.Length > 0 && (DateTime.Now - _partialAt).TotalMilliseconds > 300) FlushPartial();
            }
        }
    }

    /// <summary>Сменился мост (или мост перестал отвечать) — оборвать соединение.</summary>
    public void Reconnect()
    {
        lock (_lock)
        {
            try { _tcp?.Dispose(); } catch { }
        }
    }

    static async Task<bool> Pause(int ms, CancellationToken ct)
    {
        try
        {
            await Task.Delay(ms, ct);
            return true;
        }
        catch (OperationCanceledException)
        {
            return false;
        }
    }

    // ============================================================ разбор

    void Feed(byte[] b)
    {
        bool panel = false;
        lock (_lock)
        {
            _rxBytes += b.Length;
            if (_mode == "off") return;
            long before = _ld.Frames;
            if (_mode is "auto" or "ld2410")
            {
                _ld.Feed(b, 0, b.Length, r =>
                {
                    // панель перерисовываем, только когда показание изменилось (кадры идут ~10 раз в секунду)
                    string key = Describe(r);
                    if (key != _panelKey || (DateTime.Now - _lastReport).TotalSeconds > 2) panel = true;
                    _panelKey = key;
                    OnReport(r);
                }, (cmd, status) =>
                {
                    string? name = Ld2410.CommandName(cmd);
                    string s = $"LD2410: ответ на команду 0x{cmd:X4}" + (name != null ? $" ({name})" : "") +
                               (status < 0 ? "" : status == 0 ? " — выполнена" : $" — ошибка {status}");
                    Out(s, status > 0 ? Kind.Warn : Kind.Info, true);
                });
            }
            bool gotFrames = _ld.Frames != before;
            bool ldRecent = _last != null && (DateTime.Now - _lastReport).TotalSeconds <= 3;
            if (_mode == "ld2410" || (_mode == "auto" && (gotFrames || ldRecent)))
            {
                if (gotFrames)
                {
                    _bytesSinceFrame = 0;
                    _noFramesWarned = false;
                }
                else
                {
                    _bytesSinceFrame += b.Length;
                    if (_mode == "ld2410" && _bytesSinceFrame > 300 && !_noFramesWarned)
                    {
                        _noFramesWarned = true;
                        Out("LD2410: байты приходят, но кадров радара в них нет — проверьте скорость " +
                            "(у радара по умолчанию 256000: :aux uart 256000) или выберите :auxview hex", Kind.Warn, true);
                    }
                }
            }
            else if (_mode == "hex" || (_mode == "auto" && !LooksLikeText(b)))
            {
                FlushPartial();
                _utf8.Reset();
                for (int off = 0; off < b.Length; off += 32)
                {
                    int end = Math.Min(b.Length, off + 32);
                    var sb = new StringBuilder(96);
                    for (int i = off; i < end; i++)
                    {
                        if (i > off) sb.Append(' ');
                        sb.Append(b[i].ToString("X2"));
                    }
                    Out(sb.ToString(), Kind.Raw, false);
                }
            }
            else
            {
                Text(b);
            }
        }
        if (panel) PanelChanged?.Invoke();
    }

    void OnReport(Ld2410.Report r)
    {
        if (!_ldAnnounced)
        {
            _ldAnnounced = true;
            Out("Распознан радар LD2410: его состояние — на панели; :auxview ld2410 1 — строка каждую секунду, " +
                ":auxview hex — сырые кадры", Kind.Info, true);
        }
        _last = r;
        _lastReport = DateTime.Now;
        int presence = r.State == 0 ? 0 : 1;
        if (presence != _prevPresence)
        {
            if (_prevPresence >= 0 || presence == 1)
            {
                Out("LD2410: " + (presence == 1 ? "человек обнаружен — " + Describe(r) : "никого нет"),
                    presence == 1 ? Kind.Good : Kind.Info, true);
                _lastLdLine = DateTime.Now;
            }
            _prevPresence = presence;
        }
        else if (_ldPeriodSec > 0 && (DateTime.Now - _lastLdLine).TotalMilliseconds >= _ldPeriodSec * 1000 - 50)
        {
            Out("LD2410: " + Describe(r) + Gates(r), Kind.Raw, false);
            _lastLdLine = DateTime.Now;
        }
    }

    /// <summary>Номер ворот по расстоянию: по умолчанию у LD2410 ворота по 75 см, всего 0…8.</summary>
    static int Gate(int cm) => Math.Min(8, cm / 75);

    static string Describe(Ld2410.Report r) => r.State switch
    {
        1 => $"движение {r.MoveCm} см (ворота {Gate(r.MoveCm)}, энергия {r.MoveEnergy})",
        2 => $"неподвижная цель {r.StillCm} см (ворота {Gate(r.StillCm)}, энергия {r.StillEnergy})",
        3 => $"движение {r.MoveCm} см (ворота {Gate(r.MoveCm)}, энергия {r.MoveEnergy}), " +
             $"неподвижная цель {r.StillCm} см (ворота {Gate(r.StillCm)}, энергия {r.StillEnergy})",
        _ => "никого нет",
    };

    static string Gates(Ld2410.Report r)
    {
        if (!r.Engineering) return "";
        string s = " | ворота: движ. " + string.Join(' ', r.MoveGates) + ", неподв. " + string.Join(' ', r.StillGates);
        if (r.Light >= 0) s += $", свет {r.Light}, OUT {r.Out}";
        return s;
    }

    /// <summary>Сегменты панели: состояние радара; пусто — радара нет.</summary>
    public List<Segment> PanelSegments()
    {
        var segs = new List<Segment>();
        lock (_lock)
        {
            if (_last is not Ld2410.Report r) return segs;
            double age = (DateTime.Now - _lastReport).TotalSeconds;
            if (age > 10) return segs;
            segs.Add(new Segment("Радар ", ConsoleColor.DarkCyan));
            if (age > 3)
            {
                segs.Add(new Segment("нет данных", ConsoleColor.DarkGray));
                return segs;
            }
            string t = r.State switch
            {
                1 => $"движ. в{Gate(r.MoveCm)} {r.MoveCm} см/{r.MoveEnergy}",
                2 => $"неподв. в{Gate(r.StillCm)} {r.StillCm} см/{r.StillEnergy}",
                3 => $"движ. в{Gate(r.MoveCm)} {r.MoveCm} см/{r.MoveEnergy}, " +
                     $"неподв. в{Gate(r.StillCm)} {r.StillCm} см/{r.StillEnergy}",
                _ => "никого",
            };
            segs.Add(new Segment(t, r.State == 0 ? ConsoleColor.Gray : ConsoleColor.Green));
        }
        return segs;
    }

    static bool LooksLikeText(byte[] b)
    {
        int i = 0;
        // начало могло быть продолжением символа UTF-8 из прошлого куска
        while (i < b.Length && i < 3 && (b[i] & 0xC0) == 0x80) i++;
        while (i < b.Length)
        {
            int x = b[i];
            if (x < 0x80)
            {
                if ((x < 0x20 && x != '\n' && x != '\r' && x != '\t') || x == 0x7F) return false;
                i++;
                continue;
            }
            int need = x >= 0xF0 && x < 0xF8 ? 3 : x >= 0xE0 && x < 0xF0 ? 2 : x >= 0xC2 && x < 0xE0 ? 1 : -1;
            if (need < 0) return false;
            for (int k = 1; k <= need; k++)
            {
                if (i + k >= b.Length) return true;
                if ((b[i + k] & 0xC0) != 0x80) return false;
            }
            i += need + 1;
        }
        return true;
    }

    void Text(byte[] b)
    {
        int count = _utf8.GetChars(b, 0, b.Length, _chars, 0, flush: false);
        for (int i = 0; i < count; i++)
        {
            char c = _chars[i];
            if (c == '\n')
            {
                Out(_partial.ToString(), Kind.Raw, false);
                _partial.Clear();
            }
            else if (c >= ' ' || c == '\t')
            {
                if (_partial.Length == 0) _partialAt = DateTime.Now;
                _partial.Append(c == '\t' ? "    " : c.ToString());
                if (_partial.Length >= 2000) FlushPartial();
            }
        }
    }

    void FlushPartial()
    {
        if (_partial.Length == 0) return;
        Out(_partial.ToString(), Kind.Raw, false);
        _partial.Clear();
    }

    void Out(string text, Kind kind, bool ev)
    {
        string line = (ev || _ui.Timestamps ? DateTime.Now.ToString("[HH:mm:ss.fff] ") : "") + "AUX› " + text;
        ConsoleColor c = kind switch
        {
            Kind.Good => ConsoleColor.Green,
            Kind.Warn => ConsoleColor.Red,
            Kind.Info => ConsoleColor.Yellow,
            _ => ConsoleColor.Magenta,
        };
        _ui.Line(line, c);
        _log("AUX› " + text);                 // журнал сам ставит метку времени
    }

    // ============================================================ команда :auxview

    public void Command(string arg)
    {
        string[] p = arg.ToLowerInvariant().Split(' ', StringSplitOptions.RemoveEmptyEntries);
        lock (_lock)
        {
            if (p.Length == 0)
            {
                _ui.Info($"Второй поток (XP2.6): показ «{_mode}»" +
                         (_ldPeriodSec > 0 ? $", радар — строка раз в {_ldPeriodSec} с" : "") +
                         $"; принято {_rxBytes} байт; кадров LD2410: {_ld.Frames}, испорченных {_ld.BadFrames}");
                _ui.Info("Варианты: auto | text | hex | ld2410 [секунд] | off. Включить приём на мосту: :aux uart 256000");
                return;
            }
            if (!Modes.Contains(p[0]))
            {
                _ui.Warn("Варианты: auto | text | hex | ld2410 [секунд] | off");
                return;
            }
            FlushPartial();
            _utf8.Reset();
            _ld.Reset();
            _mode = p[0];
            _bytesSinceFrame = 0;
            _noFramesWarned = false;
            if (_mode is "ld2410" or "auto")
            {
                int sec = 0;
                if (p.Length > 1 && (!int.TryParse(p[1], out sec) || sec < 0 || sec > 3600))
                {
                    _ui.Warn("Период — целое число секунд 0…3600 (0 — только при появлении и уходе человека)");
                    sec = 0;
                }
                _ldPeriodSec = sec;
            }
            string what = _mode switch
            {
                "text" => "текст",
                "hex" => "шестнадцатеричный вывод",
                "ld2410" => "радар LD2410" + (_ldPeriodSec > 0 ? $", строка раз в {_ldPeriodSec} с" : ""),
                "off" => "не показывать",
                _ => "auto — радар LD2410 узнаётся сам, остальное текстом или hex",
            };
            _ui.Info("Второй поток (XP2.6): " + what);
        }
    }

    /// <summary>Для :status — сводка по кадрам радара (или null).</summary>
    public string? LdSummary()
    {
        lock (_lock)
            return _ld.Frames > 0 || _ld.BadFrames > 0
                ? $"Радар LD2410: кадров {_ld.Frames}, испорченных {_ld.BadFrames}"
                : null;
    }
}
