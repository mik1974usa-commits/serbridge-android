/*
  SerialBridge — беспроводной мост UART <-> TCP для отладки Arduino Nano

  Плата:  ESP32 DevKit (ESP-WROOM-32), «ESP32 Dev Module» в Arduino IDE
  Ядро:   Arduino core for ESP32 2.0.x или 3.x
  Связь с МК (3,3…5 В) через модуль уровней A3 (4 × BSS138):
    D17 = TX2 → LV1/HV1 → RX МК,  D16 = RX2 ← LV2/HV2 ← TX МК,  D4 → LV3/HV3 → RESET МК
    D18 ↔ LV4/HV4 ↔ XP2.6 — дополнительная двунаправленная линия (команда aux)
          или второй приёмник UART (aux uart <бод>): TX другого устройства → XP2.6, см. AuxRx.h
    D34 ← делитель 100к/100к от Vcc МК (XP2.3): пока у МК нет питания, D17 и D4 отключены
          (высокий импеданс), чтобы не подпитывать выключенный МК через модуль уровней

  Сетевые порты:
    2323/TCP — поток данных, прозрачный: байты UART <-> байты TCP
    2324/TCP — команды управления, по одной текстовой строке:
               status | baud [n] | clear | reset [мс] | aux [0|1|pulse мс] | aux uart <бод>|off |
               tpwr | tsense on|off | tcal <В>|reset |
               ssid <имя> | pass <пароль> |
               name <имя> | restart | help
               ответ — одна строка, начинается с OK или ERR
    2325/UDP — поиск в сети: запрос "SERBRIDGE?" → ответ "SERBRIDGE name=... data=... ctrl=... baud=..."
    2326/TCP — измерения напряжений с ADS1115 (см. Meter.h), команды vch, vrate, vname, vk, vcal...
    2327/TCP — поток второго приёмника (XP2.6 → D18, UART1), только чтение (см. AuxRx.h)

  Те же команды принимаются из монитора порта по USB (115200 бод, окончание строки NL),
  так удобно один раз задать сеть:  ssid МояСеть  →  pass МойПароль  →  restart

  Клиентов может быть несколько (консоль на ПК, телефон…): до MAX_DATA_CLIENTS на порт данных
  и столько же на порт измерений. Вывод МК получают все, ввести строку в МК может любой.
  Пока не подключён ни один клиент, вывод МК копится в буфере (32 КБ) и отдаётся первому
  подключившемуся; следующие получают вывод с момента своего подключения.
*/

#include <WiFi.h>
#include <WiFiUdp.h>
#include <ESPmDNS.h>
#include <Preferences.h>
#include <lwip/sockets.h>
#include <errno.h>

// ===================== Настройки =====================
#define DEFAULT_WIFI_SSID  ""            // сеть WiFi (можно задать позже командой ssid)
#define DEFAULT_WIFI_PASS  ""            // пароль     (или командой pass)
#define DEFAULT_NAME       "serbridge"   // имя устройства, mDNS: serbridge.local
#define DEFAULT_BAUD       115200        // скорость UART тестируемого МК

#define AP_PASS            "serbridge"   // пароль резервной точки доступа (не короче 8 символов)

#define UART_RX_PIN   16                 // D16 ← LV2/HV2 ← TX МК (XP2.2)
#define UART_TX_PIN   17                 // D17 → LV1/HV1 → RX МК (XP2.1)
#define LED_PIN       2                  // светодиод D2 на плате
#define LED_ON        HIGH
#define TARGET_RST_PIN 4                 // D4 → канал 3 модуля уровней (LV3/HV3) → RESET отлаживаемого МК
#define RESET_PULSE_MS 100               // длительность импульса сброса по умолчанию
#define TARGET_AUX_PIN 18                // D18 ↔ канал 4 модуля уровней (LV4/HV4) ↔ XP2.6
#define TPWR_PIN       34                // D34 ← делитель 100к/100к от Vcc МК (XP2.3)
#define TPWR_K         2.0f              // коэффициент делителя
#define TPWR_ON_V      2.8f              // питание МК появилось: включить UART
#define TPWR_OFF_V     2.5f              // питание МК пропало: отключить D17 и D4
#define TPWR_SAMPLE_MS 5                 // период измерения
#define TPWR_AVG       8                 // усреднение: решение раз в 40 мс

#define DATA_PORT     2323
#define CTRL_PORT     2324
#define DISC_PORT     2325

#define HISTORY_SIZE    (32 * 1024)      // буфер вывода МК, байт (степень двойки)
#define MAX_DATA_CLIENTS 3               // одновременных клиентов на порту данных
#define MAX_CTRL_CLIENTS 2               // одновременных соединений управления
#define FLUSH_SIZE      1024             // отправлять в сеть, когда накопилось столько байт...
#define FLUSH_IDLE_US   3000             // ...или линия UART молчит столько микросекунд...
#define FLUSH_MAX_MS    20               // ...или данные ждут дольше этого
#define TCP_CHUNK       1436             // байт за один вызов write()

#define STA_TIMEOUT_MS  20000            // сколько ждать роутер при старте, потом — точка доступа
#define AP_RETRY_MS     60000            // в режиме точки доступа: как часто пробовать роутер снова
#define AP_TRY_STA_MS   15000            // длительность одной такой попытки
#define CTRL_IDLE_MS    30000            // закрыть молчащее управляющее соединение

HardwareSerial &Target = Serial2;        // UART тестируемого МК

#define LOG(fmt, ...) Serial.printf("[мост] " fmt "\n", ##__VA_ARGS__)

// ===================== Клиенты =====================
// Структуры описаны до первой функции: Arduino IDE вставляет объявления функций
// перед первой из них, и типы параметров к этому месту уже должны быть известны.
struct DataClient {
  WiFiClient c;
  bool used = false;
  uint32_t pos = 0;                      // позиция чтения в hist
  uint32_t lost = 0;                     // потеряно байт (отстал больше чем на буфер)
  uint32_t since = 0;                    // millis() подключения
};
DataClient dcl[MAX_DATA_CLIENTS];
int dataCount = 0;                       // подключено клиентов данных

struct CtrlClient {
  WiFiClient c;
  bool used = false;
  String line;
  uint32_t lastMs = 0;
};
CtrlClient ccl[MAX_CTRL_CLIENTS];

// ===================== Буфер вывода МК =====================
// Один кольцевой буфер на всех клиентов: позиции — сквозные счётчики байт (uint32_t,
// переполнение счётчика не мешает: размер буфера — степень двойки). У каждого клиента
// своя позиция чтения; медленный клиент, отставший больше чем на размер буфера,
// теряет самые старые байты, остальные этого не замечают.
static_assert((HISTORY_SIZE & (HISTORY_SIZE - 1)) == 0, "HISTORY_SIZE — степень двойки");
uint8_t hist[HISTORY_SIZE];
uint32_t histHead = 0;                   // сколько байт записано всего
uint32_t histIdleFrom = 0;               // с этой позиции вывод ещё никто не видел (клиентов нет)
uint32_t histIdleLost = 0;               // без клиентов буфер переполнился — столько байт затёрто

void histPush(const uint8_t *d, size_t n) {
  for (size_t i = 0; i < n; i++) hist[(histHead + i) & (HISTORY_SIZE - 1)] = d[i];
  histHead += n;
  // Без клиентов «невиданное» не может быть больше буфера: подтягиваем начало и считаем потери.
  // Так разность счётчиков всегда мала и не ломается при их переполнении за долгую работу.
  if (dataCount == 0 && histHead - histIdleFrom > HISTORY_SIZE) {
    histIdleLost += (histHead - histIdleFrom) - HISTORY_SIZE;
    histIdleFrom = histHead - HISTORY_SIZE;
  }
}

// ===================== Состояние =====================
enum NetMode : uint8_t { NET_CONNECTING, NET_STA, NET_AP };

Preferences prefs;
String cfgSsid, cfgPass, cfgName, apSsid;
uint32_t cfgBaud = DEFAULT_BAUD;

WiFiServer dataServer(DATA_PORT);
WiFiServer ctrlServer(CTRL_PORT);

WiFiUDP udp;

NetMode netMode = NET_CONNECTING;
uint32_t netTimerMs = 0, apTryStartMs = 0;
bool apTrying = false, staWasUp = false, mdnsUp = false;

uint32_t lastUartRxUs = 0, pendingSinceMs = 0;
bool forceFlush = false;

uint32_t statUartRx = 0, statUartTx = 0;
uint32_t activityUntilMs = 0, restartAtMs = 0;
uint32_t targetResetUntilMs = 0;         // 0 — линия RESET отпущена
uint32_t auxPulseUntilMs = 0;            // 0 — импульса на AUX нет
bool auxLow = false;                     // AUX притянута мостом к нулю
bool targetPowered = false;              // у МК есть питание, UART включён
bool tsenseOn = true;                    // следить за питанием МК (false — UART включён всегда)
float targetVcc = 0;                     // напряжение питания МК, В
float tpwrCal = 1.0f;                    // поправка по мультиметру (команда tcal)
uint32_t statDropped = 0;                // байт из сети отброшено, пока МК без питания
String usbLine;

// ===================== Настройки в NVS =====================
void loadConfig() {
  prefs.begin("serbridge", false);
  cfgSsid = prefs.isKey("ssid") ? prefs.getString("ssid") : String(DEFAULT_WIFI_SSID);
  cfgPass = prefs.isKey("pass") ? prefs.getString("pass") : String(DEFAULT_WIFI_PASS);
  cfgName = prefs.isKey("name") ? prefs.getString("name") : String(DEFAULT_NAME);
  cfgBaud = prefs.isKey("baud") ? prefs.getUInt("baud") : (uint32_t)DEFAULT_BAUD;
  tsenseOn = prefs.isKey("tsense") ? prefs.getBool("tsense") : true;
  tpwrCal = prefs.isKey("tcal") ? prefs.getFloat("tcal") : 1.0f;
  if (!(tpwrCal >= 0.8f && tpwrCal <= 1.2f)) tpwrCal = 1.0f;
}

// ===================== WiFi =====================
void startMdns() {
  if (mdnsUp) {
    MDNS.end();
    mdnsUp = false;
  }
  if (MDNS.begin(cfgName.c_str())) {
    MDNS.addService("serbridge", "tcp", DATA_PORT);
    mdnsUp = true;
  }
}

void startSta() {
  WiFi.persistent(false);
  WiFi.setHostname(cfgName.c_str());
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);                  // без энергосбережения — меньше задержки
  WiFi.setAutoReconnect(true);
  WiFi.begin(cfgSsid.c_str(), cfgPass.c_str());
  netMode = NET_CONNECTING;
  netTimerMs = millis();
  LOG("Подключение к сети «%s»...", cfgSsid.c_str());
}

void startAp() {
  WiFi.mode(WIFI_AP);
  WiFi.softAP(apSsid.c_str(), AP_PASS);
  WiFi.setSleep(false);
  netMode = NET_AP;
  netTimerMs = millis();
  apTrying = false;
  startMdns();
  LOG("Точка доступа «%s», пароль «%s», IP %s",
      apSsid.c_str(), AP_PASS, WiFi.softAPIP().toString().c_str());
}

void onStaUp() {
  staWasUp = true;
  startMdns();
  LOG("WiFi подключён, IP %s, RSSI %d дБм",
      WiFi.localIP().toString().c_str(), (int)WiFi.RSSI());
}

void netManage() {
  uint32_t now = millis();
  switch (netMode) {
    case NET_CONNECTING:
      if (WiFi.status() == WL_CONNECTED) {
        netMode = NET_STA;
        onStaUp();
      } else if (now - netTimerMs > STA_TIMEOUT_MS) {
        LOG("Сеть «%s» недоступна — включаю точку доступа", cfgSsid.c_str());
        startAp();
      }
      break;

    case NET_STA: {
      bool up = WiFi.status() == WL_CONNECTED;
      if (up && !staWasUp) onStaUp();
      if (!up && staWasUp) {
        staWasUp = false;
        LOG("WiFi потерян, переподключение...");
      }
      break;
    }

    case NET_AP:
      if (cfgSsid.length() == 0) break;  // сеть не задана — остаёмся точкой доступа
      if (!apTrying) {
        // К точке доступа никто не подключён — пробуем снова найти роутер
        if (now - netTimerMs > AP_RETRY_MS && WiFi.softAPgetStationNum() == 0) {
          WiFi.mode(WIFI_AP_STA);
          WiFi.begin(cfgSsid.c_str(), cfgPass.c_str());
          apTrying = true;
          apTryStartMs = now;
        }
      } else if (WiFi.status() == WL_CONNECTED) {
        WiFi.softAPdisconnect(true);
        WiFi.mode(WIFI_STA);
        WiFi.setAutoReconnect(true);
        netMode = NET_STA;
        onStaUp();
      } else if (now - apTryStartMs > AP_TRY_STA_MS) {
        WiFi.disconnect();
        WiFi.mode(WIFI_AP);
        apTrying = false;
        netTimerMs = now;
      }
      break;
  }
}

// ===================== TCP-клиенты =====================
void setKeepAlive(WiFiClient &c) {
  int fd = c.fd();
  if (fd < 0) return;
  int on = 1;
  setsockopt(fd, SOL_SOCKET, SO_KEEPALIVE, &on, sizeof(on));
#ifdef TCP_KEEPIDLE
  int idle = 5, intvl = 2, cnt = 3;      // обрыв обнаруживается примерно за 11 с
  setsockopt(fd, IPPROTO_TCP, TCP_KEEPIDLE, &idle, sizeof(idle));
  setsockopt(fd, IPPROTO_TCP, TCP_KEEPINTVL, &intvl, sizeof(intvl));
  setsockopt(fd, IPPROTO_TCP, TCP_KEEPCNT, &cnt, sizeof(cnt));
#endif
}

// connected() не замечает штатного закрытия (FIN) — проверяем сокет напрямую
bool clientAlive(WiFiClient &c) {
  if (!c.connected()) return false;
  int fd = c.fd();
  if (fd < 0) return false;
  uint8_t d;
  int r = recv(fd, &d, 1, MSG_PEEK | MSG_DONTWAIT);
  if (r == 0) return false;                                   // клиент закрыл соединение
  if (r < 0 && errno != EAGAIN && errno != EWOULDBLOCK) return false;
  return true;
}

// Сколько байт ждёт отправки у клиента (не больше размера буфера)
uint32_t dataPending(const DataClient &d) {
  uint32_t p = histHead - d.pos;
  return p > HISTORY_SIZE ? HISTORY_SIZE : p;
}

uint32_t maxPending() {
  uint32_t m = 0;
  for (auto &d : dcl)
    if (d.used && dataPending(d) > m) m = dataPending(d);
  return m;
}

void dropDataClient(DataClient &d, const char *why) {
  if (!d.used) return;
  String ip = d.c.remoteIP().toString();
  d.c.stop();
  d.used = false;
  dataCount--;
  if (dataCount == 0) {                         // неотправленное отдадим следующему клиенту
    uint32_t behind = histHead - d.pos;
    if (behind > HISTORY_SIZE) {
      histIdleLost = behind - HISTORY_SIZE;
      histIdleFrom = histHead - HISTORY_SIZE;
    } else {
      histIdleLost = 0;
      histIdleFrom = d.pos;
    }
  }
  LOG("Клиент %s: %s (осталось клиентов: %d)", ip.c_str(), why, dataCount);
}

// Кого вытеснить, когда мест нет: 1) прежнее соединение с того же адреса (устройство
// переподключилось, а старое ещё не закрыто); 2) клиента, который давно не принимает данные
// (у него копится очередь — скорее всего, он ушёл из сети); 3) самое старое соединение.
DataClient *dataVictim(IPAddress ip) {
  DataClient *v = nullptr;
  for (auto &d : dcl)
    if (d.used && d.c.remoteIP() == ip && (!v || d.since - v->since > 0x80000000UL)) v = &d;
  if (v) return v;
  for (auto &d : dcl)
    if (d.used && dataPending(d) >= 4096 && (!v || dataPending(d) > dataPending(*v))) v = &d;
  if (v) return v;
  v = &dcl[0];
  for (auto &d : dcl)
    if (d.since - v->since > 0x80000000UL) v = &d;
  return v;
}

void acceptData() {
  while (dataServer.hasClient()) {
    WiFiClient c = dataServer.accept();
    if (!c) break;
    DataClient *slot = nullptr;
    for (auto &d : dcl)
      if (!d.used) { slot = &d; break; }
    if (!slot) {                         // мест нет — вытесняем (см. dataVictim)
      slot = dataVictim(c.remoteIP());
      dropDataClient(*slot, "вытеснен новым клиентом");
    }
    slot->c = c;
    slot->used = true;
    slot->since = millis();
    slot->lost = 0;
    if (dataCount == 0) {
      // Первый клиент получает всё, что накопилось без клиентов (сколько поместилось в буфер)
      slot->pos = histIdleFrom;
      slot->lost = histIdleLost;
      histIdleLost = 0;
    } else {
      slot->pos = histHead;              // остальные — вывод с момента подключения
    }
    dataCount++;
    slot->c.setNoDelay(true);
    setKeepAlive(slot->c);
    forceFlush = true;                   // сразу отдать накопленное
    LOG("Клиент %s подключён (клиентов: %d), к отправке %u байт",
        slot->c.remoteIP().toString().c_str(), dataCount, (unsigned)dataPending(*slot));
  }
  for (auto &d : dcl)
    if (d.used && !clientAlive(d.c)) dropDataClient(d, "отключился");
}

void dropCtrl(CtrlClient &k) {
  k.c.stop();
  k.used = false;
  k.line = "";
}

void acceptCtrl() {
  while (ctrlServer.hasClient()) {
    WiFiClient c = ctrlServer.accept();
    if (!c) break;
    CtrlClient *slot = nullptr;
    for (auto &k : ccl)
      if (!k.used) { slot = &k; break; }
    if (!slot) {                         // мест нет — закрываем самое давно молчащее
      slot = &ccl[0];
      for (auto &k : ccl)
        if (k.lastMs - slot->lastMs > 0x80000000UL) slot = &k;
      dropCtrl(*slot);
    }
    slot->c = c;
    slot->used = true;
    slot->line = "";
    slot->lastMs = millis();
  }
  for (auto &k : ccl)
    if (k.used && (!k.c.connected() || millis() - k.lastMs > CTRL_IDLE_MS)) dropCtrl(k);
}

void acceptClients() {
  acceptData();
  acceptCtrl();
}

// ===================== Передача данных =====================
void uartToNet() {
  static uint8_t buf[512];
  int avail;
  while (targetPowered && (avail = Target.available()) > 0) {
    size_t n = Target.read(buf, (size_t)avail < sizeof(buf) ? (size_t)avail : sizeof(buf));
    if (n == 0) break;
    if (maxPending() == 0) pendingSinceMs = millis();
    histPush(buf, n);
    statUartRx += n;
    lastUartRxUs = micros();
  }

  if (dataCount == 0) return;
  uint32_t pend = maxPending();
  if (pend == 0) return;

  bool idle = (uint32_t)(micros() - lastUartRxUs) >= FLUSH_IDLE_US;
  bool big  = pend >= FLUSH_SIZE;
  bool old  = (uint32_t)(millis() - pendingSinceMs) >= FLUSH_MAX_MS;
  if (!(idle || big || old || forceFlush)) return;
  forceFlush = false;

  // Неблокирующая отправка, не больше 4 пакетов на клиента за проход: если сеть у одного
  // клиента притормозила, его данные ждут в буфере, а остальные клиенты и приём из UART не страдают
  bool left = false;
  for (auto &d : dcl) {
    if (!d.used) continue;
    uint32_t behind = histHead - d.pos;
    if (behind > HISTORY_SIZE) {         // отстал больше чем на буфер — старое уже затёрто
      d.lost += behind - HISTORY_SIZE;
      d.pos = histHead - HISTORY_SIZE;
    }
    for (int i = 0; i < 4 && d.pos != histHead; i++) {
      uint32_t off = d.pos & (HISTORY_SIZE - 1);
      uint32_t len = histHead - d.pos;
      if (len > HISTORY_SIZE - off) len = HISTORY_SIZE - off;
      if (len > TCP_CHUNK) len = TCP_CHUNK;
      int w = send(d.c.fd(), &hist[off], len, MSG_DONTWAIT);
      if (w < 0) {
        if (errno == EAGAIN || errno == EWOULDBLOCK) break;  // буфер TCP занят — позже
        dropDataClient(d, "ошибка передачи — соединение закрыто");
        break;
      }
      if (w == 0) break;
      d.pos += (uint32_t)w;
      activityUntilMs = millis() + 30;
    }
    if (d.used && d.pos != histHead) left = true;
  }
  if (left) forceFlush = true;           // остаток — на следующем проходе
  else pendingSinceMs = millis();
}

void netToUart() {
  if (dataCount == 0) return;
  static uint8_t buf[256];
  for (auto &d : dcl) {
    if (!d.used) continue;
    int av = d.c.available();
    if (av <= 0) continue;
    if (!targetPowered) {                  // МК без питания: принять из сети и отбросить
      int n = d.c.read(buf, av < (int)sizeof(buf) ? av : (int)sizeof(buf));
      if (n > 0) statDropped += n;
      continue;
    }
    int space = Target.availableForWrite();  // не читать из сети больше, чем влезет в UART
    if (space <= 0) return;
    int n = av;
    if (n > space) n = space;
    if (n > (int)sizeof(buf)) n = sizeof(buf);
    n = d.c.read(buf, n);
    if (n > 0) {
      Target.write(buf, n);
      statUartTx += n;
      activityUntilMs = millis() + 30;
    }
  }
}

// ===================== Дополнительная линия AUX (D18 ↔ XP2.6) =====================
// Канал BSS138 двунаправленный: мост либо тянет линию к нулю (выход 0), либо отпускает её
// (вход) — тогда единицу дают подтяжки модуля, а МК может сам тянуть линию к нулю, и мост это читает.
// Активную единицу мост не выдаёт: так линия безопасна при любом направлении («открытый сток»).
void auxRelease() {
  pinMode(TARGET_AUX_PIN, INPUT);
  auxLow = false;
  auxPulseUntilMs = 0;
}

void auxDriveLow() {
  pinMode(TARGET_AUX_PIN, OUTPUT);
  digitalWrite(TARGET_AUX_PIN, LOW);
  auxLow = true;
}

#include "AuxRx.h"                       // второй приёмник UART на той же линии

// ===================== Питание отлаживаемого МК =====================
// Модуль уровней на BSS138 пропускает ток со стороны 3,3 В (ESP32) на сторону выключенного МК
// через встроенные диоды транзисторов: единица на D17 подпитывала бы МК до ~2 В.
// Поэтому, пока на XP2.3 нет питания, UART2 остановлен, а D17 и D4 — входы (высокий импеданс).
void targetUartOn() {
  Target.setRxBufferSize(4096);          // до begin(); после end() размеры задаются заново
  Target.setTxBufferSize(2048);
  Target.begin(cfgBaud, SERIAL_8N1, UART_RX_PIN, UART_TX_PIN);
}

void targetUartOff() {
  Target.end();
  pinMode(UART_TX_PIN, INPUT);           // без подтяжки — ток в выключенный МК не идёт
  pinMode(UART_RX_PIN, INPUT);
  targetResetUntilMs = 0;
  pinMode(TARGET_RST_PIN, INPUT);
  if (!auxUartActive()) auxRelease();    // приёмник на D18 не трогаем: он ничего не выдаёт в линию
}

void setTargetPowered(bool on) {
  if (on == targetPowered) return;
  targetPowered = on;
  if (on) {
    targetUartOn();
    if (tsenseOn) LOG("Питание МК %.2f В — UART включён", targetVcc);
    else LOG("Контроль питания МК выключен — UART включён");
  } else {
    targetUartOff();
    LOG("МК без питания (%.2f В) — D17 и D4 отключены", targetVcc);
  }
}

float readTargetVcc() {
  return analogReadMilliVolts(TPWR_PIN) * (TPWR_K / 1000.0f) * tpwrCal;
}

void targetPowerTick() {
  static uint32_t lastMs = 0;
  static float acc = 0;
  static uint8_t n = 0;
  uint32_t now = millis();
  if (now - lastMs < TPWR_SAMPLE_MS) return;
  lastMs = now;
  acc += readTargetVcc();
  if (++n < TPWR_AVG) return;
  targetVcc = acc / n;
  acc = 0;
  n = 0;
  if (!tsenseOn) setTargetPowered(true);
  else if (!targetPowered && targetVcc >= TPWR_ON_V) setTargetPowered(true);
  else if (targetPowered && targetVcc <= TPWR_OFF_V) setTargetPowered(false);
}

void targetPowerSetup() {
  pinMode(UART_TX_PIN, INPUT);
  pinMode(UART_RX_PIN, INPUT);
  float acc = 0;
  for (int i = 0; i < TPWR_AVG; i++) acc += readTargetVcc();
  targetVcc = acc / TPWR_AVG;
  if (!tsenseOn || targetVcc >= TPWR_ON_V) setTargetPowered(true);
  else LOG("МК без питания (%.2f В на XP2.3) — UART включится, когда оно появится", targetVcc);
}

String targetLine() {                    // строка для потока измерений (порт 2326)
  char b[48];
  snprintf(b, sizeof(b), "T vcc=%.2f pwr=%d sense=%d", targetVcc, targetPowered ? 1 : 0,
           tsenseOn ? 1 : 0);
  return String(b);
}

// ===================== Измерение напряжений (ADS1115) =====================
#include "Meter.h"

// ===================== Команды =====================
const char *modeName() {
  switch (netMode) {
    case NET_STA: return "STA";
    case NET_AP:  return "AP";
    default:      return "CONNECTING";
  }
}

// «pending»/«lost» для status: при клиентах — у самого отстающего, без клиентов — накопленное
uint32_t statusPending() {
  if (dataCount > 0) return maxPending();
  return histHead - histIdleFrom;        // не больше буфера (см. histPush)
}

uint32_t statusLost() {
  uint32_t m = 0;
  if (dataCount == 0) return histIdleLost;
  for (auto &d : dcl)
    if (d.used && d.lost > m) m = d.lost;
  return m;
}

String statusString() {
  IPAddress ip = (netMode == NET_AP) ? WiFi.softAPIP() : WiFi.localIP();
  int rssi = (netMode == NET_STA && WiFi.status() == WL_CONNECTED) ? WiFi.RSSI() : 0;
  char b[560];
  snprintf(b, sizeof(b),
           "OK name=%s mode=%s ip=%s rssi=%d baud=%lu client=%d meters=%d pending=%u lost=%lu "
           "rx=%lu tx=%lu dropped=%lu uptime=%lu heap=%u adc=%s adcerr=%lu meter=%d tvcc=%.2f tpwr=%d tsense=%d "
           "aux=%d auxmode=%s auxbaud=%lu auxport=%d auxrx=%lu auxerr=%lu auxovf=%lu auxcl=%d auxlost=%lu",
           cfgName.c_str(), modeName(), ip.toString().c_str(), rssi,
           (unsigned long)cfgBaud, dataCount, meterCount(), (unsigned)statusPending(),
           (unsigned long)statusLost(), (unsigned long)statUartRx, (unsigned long)statUartTx,
           (unsigned long)statDropped, (unsigned long)(millis() / 1000), (unsigned)ESP.getFreeHeap(),
           adcName(), (unsigned long)adsErrCount, METER_PORT, targetVcc, targetPowered ? 1 : 0, tsenseOn ? 1 : 0,
           digitalRead(TARGET_AUX_PIN), auxBaud ? "uart" : auxLow ? "low" : "in",
           (unsigned long)auxBaud, AUX_PORT, (unsigned long)auxRxBytes, (unsigned long)auxErrFrame,
           (unsigned long)auxErrOvf, auxCount, (unsigned long)auxLostMax());
  return String(b);
}

bool validName(const String &s) {
  if (s.length() == 0 || s.length() > 32) return false;
  for (size_t i = 0; i < s.length(); i++) {
    char c = s[i];
    if (!(isalnum((unsigned char)c) || c == '-')) return false;
  }
  return true;
}

String handleCommand(String line) {
  line.trim();
  if (line.length() == 0) return "";
  int sp = line.indexOf(' ');
  String cmd = sp < 0 ? line : line.substring(0, sp);
  String arg = sp < 0 ? String("") : line.substring(sp + 1);
  arg.trim();
  cmd.toLowerCase();

  if (cmd == "status") return statusString();

  if (cmd.startsWith("v")) {
    String reply;
    if (meterCommand(cmd, arg, reply)) return reply;
  }

  if (cmd == "baud") {
    if (arg.length() == 0) return "OK baud=" + String(cfgBaud);
    uint32_t b = strtoul(arg.c_str(), nullptr, 10);
    if (b < 300 || b > 2000000) return "ERR скорость должна быть от 300 до 2000000";
    if (targetPowered) Target.updateBaudRate(b);   // иначе применится при включении UART
    cfgBaud = b;
    prefs.putUInt("baud", b);
    LOG("Скорость UART: %lu бод", (unsigned long)b);
    return "OK baud=" + String(b);
  }

  if (cmd == "clear") {
    for (auto &d : dcl) {
      d.pos = histHead;
      d.lost = 0;
    }
    histIdleFrom = histHead;
    histIdleLost = 0;
    return "OK буфер очищен";
  }

  if (cmd == "ssid") {
    cfgSsid = arg;
    prefs.putString("ssid", arg);
    return "OK сеть сохранена, применится после restart";
  }

  if (cmd == "pass") {
    cfgPass = arg;
    prefs.putString("pass", arg);
    return "OK пароль сохранён, применится после restart";
  }

  if (cmd == "name") {
    if (!validName(arg)) return "ERR имя: латиница, цифры и '-', до 32 символов";
    cfgName = arg;
    prefs.putString("name", arg);
    return "OK имя сохранено, применится после restart";
  }

  if (cmd == "reset") {
    // Сброс отлаживаемого МК: D4 на время импульса выдаёт 0, затем снова вход.
    // В покое линию держит в «1» подтяжка модуля уровней (и самого МК).
    uint32_t ms = arg.length() ? strtoul(arg.c_str(), nullptr, 10) : RESET_PULSE_MS;
    if (ms < 1 || ms > 5000) return "ERR длительность импульса 1…5000 мс";
    if (!targetPowered) return "ERR МК без питания (нет напряжения на XP2.3)";
    pinMode(TARGET_RST_PIN, OUTPUT);
    digitalWrite(TARGET_RST_PIN, LOW);
    targetResetUntilMs = millis() + ms;
    if (targetResetUntilMs == 0) targetResetUntilMs = 1;
    LOG("Сброс МК, импульс %lu мс", (unsigned long)ms);
    return "OK сброс МК";
  }

  if (cmd == "aux") {
    // aux — прочитать линию; aux 0 — притянуть к нулю; aux 1 — отпустить (вход);
    // aux pulse [мс] — импульс нуля (по умолчанию 100 мс)
    // aux uart <бод> — линия становится вторым приёмником UART (порт 2327); aux off — обратно
    {
      String r;
      if (auxUartCommand(arg, r)) return r;
    }
    if (arg.length() == 0) {
      return String("OK aux=") + digitalRead(TARGET_AUX_PIN) + " mode=" + (auxLow ? "low" : "in");
    }
    if (!targetPowered) return "ERR МК без питания (нет напряжения на XP2.3)";
    if (arg == "0") {
      auxDriveLow();
      return "OK aux=0 (мост тянет линию к нулю)";
    }
    if (arg == "1" || arg == "in") {
      auxRelease();
      return String("OK линия отпущена, aux=") + digitalRead(TARGET_AUX_PIN);
    }
    if (arg.startsWith("pulse")) {
      String a = arg.substring(5);
      a.trim();
      uint32_t ms = a.length() ? strtoul(a.c_str(), nullptr, 10) : 100;
      if (ms < 1 || ms > 5000) return "ERR длительность импульса 1…5000 мс";
      auxDriveLow();
      auxPulseUntilMs = millis() + ms;
      if (auxPulseUntilMs == 0) auxPulseUntilMs = 1;
      return "OK импульс нуля на AUX, " + String(ms) + " мс";
    }
    return "ERR aux | aux 0 | aux 1 | aux pulse [мс] | aux uart <бод> | aux off";
  }

  if (cmd == "tpwr") {
    char b[64];
    snprintf(b, sizeof(b), "OK tvcc=%.2f tpwr=%d tsense=%d tcal=%.4f", targetVcc,
             targetPowered ? 1 : 0, tsenseOn ? 1 : 0, tpwrCal);
    return String(b);
  }

  if (cmd == "tcal") {
    // tcal 4.98 — подогнать показание питания МК под мультиметр; tcal reset — сбросить поправку
    char b[80];
    if (arg == "reset") {
      tpwrCal = 1.0f;
    } else if (arg.length() > 0) {
      String a = arg;
      a.replace(',', '.');
      char *end = nullptr;
      float u = strtof(a.c_str(), &end);
      if (end == nullptr || *end != '\0' || !(u >= 1.0f && u <= 6.0f))
        return "ERR укажите напряжение по мультиметру, например tcal 4.98";
      if (!(targetVcc >= 1.0f)) return "ERR на XP2.3 нет напряжения для калибровки";
      float f = tpwrCal * u / targetVcc;
      if (!(f >= 0.8f && f <= 1.2f)) {
        snprintf(b, sizeof(b), "ERR поправка вышла бы %.3f — проверьте делитель R9/R10", f);
        return String(b);
      }
      tpwrCal = f;
    } else {
      snprintf(b, sizeof(b), "OK tcal=%.4f tvcc=%.2f", tpwrCal, targetVcc);
      return String(b);
    }
    prefs.putFloat("tcal", tpwrCal);
    float acc = 0;
    for (int i = 0; i < TPWR_AVG; i++) acc += readTargetVcc();
    targetVcc = acc / TPWR_AVG;
    snprintf(b, sizeof(b), "OK поправка %.4f, питание МК %.2f В", tpwrCal, targetVcc);
    return String(b);
  }

  if (cmd == "tsense") {
    // off — для платы без делителя на D34: UART включён всегда
    if (arg != "on" && arg != "off") return String("OK tsense=") + (tsenseOn ? "on" : "off");
    tsenseOn = (arg == "on");
    prefs.putBool("tsense", tsenseOn);
    return String("OK контроль питания МК ") + (tsenseOn ? "включён" : "выключен");
  }

  if (cmd == "restart") {
    restartAtMs = millis() + 300;        // успеть отправить ответ
    if (restartAtMs == 0) restartAtMs = 1;
    return "OK перезагрузка";
  }

  if (cmd == "help") {
    return "OK команды: status | baud [n] | clear | reset [мс] | aux [0|1|pulse мс] | aux uart <бод>|off | tpwr | tsense on|off | tcal <В>|reset | "
           "ssid <имя> | pass <пароль> | "
           "name <имя> | restart | vch | vrate <Гц> | vname <n> <имя> | vk <n> <k> | "
           "vcal <n> <поправка> | vcalto <n> <В> | von <n> | voff <n>";
  }

  return "ERR неизвестная команда: " + cmd;
}

void ctrlHandle() {
  for (auto &k : ccl) {
    if (!k.used) continue;
    while (k.c.available() > 0) {
      int c = k.c.read();
      if (c < 0) break;
      k.lastMs = millis();
      if (c == '\n') {
        String reply = handleCommand(k.line);
        k.line = "";
        if (reply.length()) {
          reply += "\n";
          k.c.write((const uint8_t *)reply.c_str(), reply.length());
        }
      } else if (c != '\r' && k.line.length() < 200) {
        k.line += (char)c;
      }
    }
  }
}

void usbConsole() {
  while (Serial.available() > 0) {
    int c = Serial.read();
    if (c == '\n' || c == '\r') {
      if (usbLine.length()) {
        String reply = handleCommand(usbLine);
        Serial.println(reply);
      }
      usbLine = "";
    } else if (usbLine.length() < 200) {
      usbLine += (char)c;
    }
  }
}

void udpHandle() {
  int size = udp.parsePacket();
  if (size <= 0) return;
  uint8_t req[32];
  int n = udp.read(req, sizeof(req) - 1);
  if (n < 0) n = 0;
  req[n] = 0;
  if (strncmp((const char *)req, "SERBRIDGE?", 10) != 0) return;

  char reply[240];
  snprintf(reply, sizeof(reply),
           "SERBRIDGE name=%s data=%d ctrl=%d meter=%d aux=%d baud=%lu mode=%s client=%d adc=%s auxbaud=%lu",
           cfgName.c_str(), DATA_PORT, CTRL_PORT, METER_PORT, AUX_PORT, (unsigned long)cfgBaud, modeName(),
           dataCount, adcName(), (unsigned long)auxBaud);
  udp.beginPacket(udp.remoteIP(), udp.remotePort());
  udp.write((const uint8_t *)reply, strlen(reply));
  udp.endPacket();
}

// ===================== Светодиод =====================
// клиент подключён — горит (гаснет на миг при обмене данными)
// в сети, клиента нет — короткая вспышка раз в секунду
// точка доступа — двойная вспышка раз в секунду
// поиск сети — частое мигание
void ledUpdate() {
  uint32_t t = millis();
  bool on;
  if (dataCount > 0) {
    on = (int32_t)(t - activityUntilMs) >= 0;
  } else if (netMode == NET_AP) {
    uint32_t ph = t % 1000;
    on = ph < 80 || (ph >= 200 && ph < 280);
  } else if (netMode == NET_STA && WiFi.status() == WL_CONNECTED) {
    on = (t % 1000) < 50;
  } else {
    on = (t / 100) % 2;
  }
  digitalWrite(LED_PIN, on ? LED_ON : !LED_ON);
}

// ===================== setup / loop =====================
void setup() {
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);
  pinMode(TARGET_RST_PIN, INPUT);        // RESET МК отпущен
  pinMode(TARGET_AUX_PIN, INPUT);        // AUX отпущена
  delay(200);

  loadConfig();

  uint64_t mac = ESP.getEfuseMac();
  char sfx[8];
  snprintf(sfx, sizeof(sfx), "%02X%02X", (uint8_t)(mac >> 32), (uint8_t)(mac >> 40));
  apSsid = String("SerBridge-") + sfx;

  LOG("SerialBridge: UART2 RX=D%d TX=D%d, %lu бод", UART_RX_PIN, UART_TX_PIN,
      (unsigned long)cfgBaud);
  targetPowerSetup();                    // UART включается, только если у МК есть питание

  if (cfgSsid.length() > 0) {
    startSta();
  } else {
    LOG("Сеть не задана: команды ssid <имя>, pass <пароль>, restart");
    startAp();
  }

  dataServer.begin();
  dataServer.setNoDelay(true);
  ctrlServer.begin();
  udp.begin(DISC_PORT);
  meterSetup();
  auxSetup();
  LOG("Порты: данные %d, управление %d, поиск %d/UDP, измерения %d, AUX %d", DATA_PORT, CTRL_PORT,
      DISC_PORT, METER_PORT, AUX_PORT);
}

void loop() {
  netManage();
  acceptClients();
  uartToNet();
  netToUart();
  ctrlHandle();
  udpHandle();
  usbConsole();
  targetPowerTick();
  meterLoop();
  auxLoop();

  if (targetResetUntilMs && (int32_t)(millis() - targetResetUntilMs) >= 0) {
    pinMode(TARGET_RST_PIN, INPUT);      // отпустить RESET
    targetResetUntilMs = 0;
  }
  if (auxPulseUntilMs && (int32_t)(millis() - auxPulseUntilMs) >= 0) auxRelease();
  ledUpdate();

  if (restartAtMs && (int32_t)(millis() - restartAtMs) >= 0) {
    for (auto &d : dcl)
      if (d.used) d.c.stop();
    for (auto &k : ccl)
      if (k.used) k.c.stop();
    meterStopAll();
    auxStopAll();
    ESP.restart();
  }
}
