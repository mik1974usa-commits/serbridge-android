using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;

namespace SerialBridgeConsole;

/// <summary>Мост, найденный в сети.</summary>
sealed record BridgeInfo(string Address, IReadOnlyDictionary<string, string> Props)
{
    public string Name => Props.GetValueOrDefault("name") ?? "?";
    public int DataPort => int.TryParse(Props.GetValueOrDefault("data"), out int p) ? p : Bridge.DefaultDataPort;
    public int CtrlPort => int.TryParse(Props.GetValueOrDefault("ctrl"), out int p) ? p : Bridge.DefaultCtrlPort;
    public int MeterPort => int.TryParse(Props.GetValueOrDefault("meter"), out int p) ? p : Bridge.DefaultMeterPort;
    public string Adc => Props.GetValueOrDefault("adc") ?? "none";
    public string Baud => Props.GetValueOrDefault("baud") ?? "?";
    public string Mode => Props.GetValueOrDefault("mode") ?? "?";
    public int Clients => int.TryParse(Props.GetValueOrDefault("client"), out int n) ? n : 0;
    public int AuxBaud => int.TryParse(Props.GetValueOrDefault("auxbaud"), out int n) ? n : 0;
}

/// <summary>Сетевые операции с мостом: поиск, команды управления, настройка сокета.</summary>
static class Bridge
{
    public const int DefaultDataPort = 2323;
    public const int DefaultCtrlPort = 2324;
    public const int DefaultDiscoveryPort = 2325;
    public const int DefaultMeterPort = 2326;

    /// <summary>"OK a=1 b=2" → {a:1, b:2}</summary>
    public static Dictionary<string, string> ParseKeyValues(string line)
    {
        var d = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (string token in line.Split(' ', StringSplitOptions.RemoveEmptyEntries))
        {
            int eq = token.IndexOf('=');
            if (eq > 0) d[token[..eq]] = token[(eq + 1)..];
        }
        return d;
    }

    /// <summary>Отправить одну команду на порт управления и получить строку ответа.</summary>
    public static async Task<string> CommandAsync(string host, int port, string command, int timeoutMs = 3000,
                                                  CancellationToken ct = default)
    {
        using var cts = CancellationTokenSource.CreateLinkedTokenSource(ct);
        cts.CancelAfter(timeoutMs);
        using var tcp = new TcpClient { NoDelay = true };
        try
        {
            await tcp.ConnectAsync(host, port, cts.Token);
            NetworkStream stream = tcp.GetStream();
            byte[] request = Encoding.UTF8.GetBytes(command + "\n");
            await stream.WriteAsync(request, cts.Token);
            using var reader = new StreamReader(stream, Encoding.UTF8, false, 512, leaveOpen: true);
            string? line = await reader.ReadLineAsync(cts.Token);
            return line?.Trim() ?? throw new IOException("мост закрыл соединение без ответа");
        }
        catch (OperationCanceledException) when (!ct.IsCancellationRequested)
        {
            throw new TimeoutException($"нет ответа от {host}:{port}");
        }
    }

    /// <summary>Широковещательный поиск мостов во всех локальных сетях.</summary>
    public static async Task<List<BridgeInfo>> DiscoverAsync(int port, int timeoutMs = 1200,
                                                             CancellationToken ct = default)
    {
        using var udp = new UdpClient(AddressFamily.InterNetwork);
        udp.EnableBroadcast = true;
        if (OperatingSystem.IsWindows())
        {
            // Не прерывать приём из-за ICMP «порт недоступен» от посторонних узлов
            const int SIO_UDP_CONNRESET = -1744830452;
            try { udp.Client.IOControl(SIO_UDP_CONNRESET, new byte[4], null); } catch { }
        }

        byte[] request = Encoding.ASCII.GetBytes("SERBRIDGE?");
        foreach (IPAddress bc in BroadcastAddresses())
        {
            try { await udp.SendAsync(request, request.Length, new IPEndPoint(bc, port)); }
            catch (SocketException) { }
        }

        var found = new Dictionary<string, BridgeInfo>();
        using var cts = CancellationTokenSource.CreateLinkedTokenSource(ct);
        cts.CancelAfter(timeoutMs);
        while (!cts.IsCancellationRequested)
        {
            try
            {
                UdpReceiveResult r = await udp.ReceiveAsync(cts.Token);
                string text = Encoding.UTF8.GetString(r.Buffer).Trim();
                if (!text.StartsWith("SERBRIDGE ")) continue;
                string ip = r.RemoteEndPoint.Address.ToString();
                found[ip] = new BridgeInfo(ip, ParseKeyValues(text));
            }
            catch (OperationCanceledException) { break; }
            catch (SocketException)
            {
                try { await Task.Delay(50, cts.Token); } catch (OperationCanceledException) { break; }
            }
        }
        return found.Values.OrderBy(b => b.Name).ThenBy(b => b.Address).ToList();
    }

    static IEnumerable<IPAddress> BroadcastAddresses()
    {
        var set = new HashSet<IPAddress> { IPAddress.Broadcast };
        foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
        {
            if (ni.OperationalStatus != OperationalStatus.Up ||
                ni.NetworkInterfaceType == NetworkInterfaceType.Loopback) continue;
            foreach (UnicastIPAddressInformation ua in ni.GetIPProperties().UnicastAddresses)
            {
                if (ua.Address.AddressFamily != AddressFamily.InterNetwork) continue;
                byte[] ip = ua.Address.GetAddressBytes();
                byte[] mask = ua.IPv4Mask.GetAddressBytes();
                if (ip.Length != 4 || mask.Length != 4) continue;
                var bc = new byte[4];
                for (int i = 0; i < 4; i++) bc[i] = (byte)(ip[i] | ~mask[i]);
                set.Add(new IPAddress(bc));
            }
        }
        return set;
    }

    /// <summary>TCP keepalive: обрыв WiFi обнаруживается за несколько секунд, а не минут.</summary>
    public static void ConfigureKeepAlive(Socket s)
    {
        try
        {
            s.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.KeepAlive, true);
            s.SetSocketOption(SocketOptionLevel.Tcp, SocketOptionName.TcpKeepAliveTime, 3);
            s.SetSocketOption(SocketOptionLevel.Tcp, SocketOptionName.TcpKeepAliveInterval, 1);
            s.SetSocketOption(SocketOptionLevel.Tcp, SocketOptionName.TcpKeepAliveRetryCount, 3);
        }
        catch (SocketException) { }
        catch (PlatformNotSupportedException) { }
    }
}
