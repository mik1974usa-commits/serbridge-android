namespace SerialBridgeConsole;

/// <summary>
/// Разбор потока радара HLK-LD2410 (LD2410B/C) по его выходу TX.
/// Кадр данных:  F4 F3 F2 F1 | длина (2 байта, LE) | данные | F8 F7 F6 F5;
/// данные: тип (01 — инженерный, 02 — обычный), AA, состояние цели, дистанция движения (2), энергия,
/// дистанция неподвижной цели (2), энергия, дистанция обнаружения (2),
/// [инженерный: N, M, энергии ворот движения ×(N+1), неподвижности ×(M+1), освещённость, OUT], 55, 00.
/// Ответ на команду: FD FC FB FA | длина | слово команды | состояние | … | 04 03 02 01.
/// Не потокобезопасен.
/// </summary>
sealed class Ld2410
{
    public sealed class Report
    {
        public int State;           // 0 — никого, 1 — движение, 2 — неподвижная цель, 3 — то и другое
        public int MoveCm, MoveEnergy, StillCm, StillEnergy, DetectCm;
        public bool Engineering;
        public int[] MoveGates = Array.Empty<int>(), StillGates = Array.Empty<int>();
        public int Light = -1, Out = -1;
    }

    const int MaxLen = 128;
    readonly byte[] _buf = new byte[512];
    int _n;

    public long Frames, BadFrames, JunkBytes;

    public void Reset() => _n = 0;

    public void Feed(byte[] b, int off, int len, Action<Report> report, Action<int, int> ack)
    {
        while (len > 0)
        {
            int k = Math.Min(len, _buf.Length - _n);
            if (k == 0)
            {
                int half = _buf.Length / 2;
                JunkBytes += half;
                Buffer.BlockCopy(_buf, half, _buf, 0, _n - half);
                _n -= half;
                continue;
            }
            Buffer.BlockCopy(b, off, _buf, _n, k);
            _n += k;
            off += k;
            len -= k;
            Parse(report, ack);
        }
    }

    int U8(int i) => _buf[i];
    int U16(int i) => _buf[i] | (_buf[i + 1] << 8);

    bool IsHeader(int i) =>
        (U8(i) == 0xF4 && U8(i + 1) == 0xF3 && U8(i + 2) == 0xF2 && U8(i + 3) == 0xF1) ||
        (U8(i) == 0xFD && U8(i + 1) == 0xFC && U8(i + 2) == 0xFB && U8(i + 3) == 0xFA);

    void Parse(Action<Report> report, Action<int, int> ack)
    {
        int i = 0;
        while (true)
        {
            int h = -1;
            for (int j = i; j + 4 <= _n; j++)
                if (IsHeader(j)) { h = j; break; }
            if (h < 0)
            {
                int keep = Math.Min(3, _n - i);
                JunkBytes += (_n - i) - keep;
                Compact(_n - keep);
                return;
            }
            JunkBytes += h - i;
            if (_n - h < 6)
            {
                Compact(h);
                return;
            }
            int len = U16(h + 4);
            if (len > MaxLen)
            {
                BadFrames++;
                i = h + 1;
                continue;
            }
            int total = 4 + 2 + len + 4;
            if (_n - h < total)
            {
                Compact(h);
                return;
            }
            int t = h + 6 + len;
            bool data = U8(h) == 0xF4;
            bool tailOk = data
                ? U8(t) == 0xF8 && U8(t + 1) == 0xF7 && U8(t + 2) == 0xF6 && U8(t + 3) == 0xF5
                : U8(t) == 0x04 && U8(t + 1) == 0x03 && U8(t + 2) == 0x02 && U8(t + 3) == 0x01;
            if (!tailOk)
            {
                BadFrames++;
                i = h + 1;
                continue;
            }
            if (data)
            {
                Report? r = Decode(h + 6, len);
                if (r == null) BadFrames++;
                else
                {
                    Frames++;
                    report(r);
                }
            }
            else if (len >= 2)
            {
                Frames++;
                ack(U16(h + 6) & ~0x0100, len >= 4 ? U16(h + 8) : -1);
            }
            else
            {
                BadFrames++;
            }
            i = h + total;
        }
    }

    void Compact(int from)
    {
        if (from <= 0) return;
        Buffer.BlockCopy(_buf, from, _buf, 0, _n - from);
        _n -= from;
    }

    Report? Decode(int d, int len)
    {
        if (len < 13) return null;
        int type = U8(d);
        if ((type != 1 && type != 2) || U8(d + 1) != 0xAA) return null;
        if (U8(d + len - 2) != 0x55 || U8(d + len - 1) != 0x00) return null;
        var r = new Report
        {
            State = U8(d + 2),
            MoveCm = U16(d + 3),
            MoveEnergy = U8(d + 5),
            StillCm = U16(d + 6),
            StillEnergy = U8(d + 8),
            DetectCm = U16(d + 9),
        };
        if (r.State > 3) return null;
        if (type == 1)
        {
            int end = len - 2;
            int p = 11;
            if (p + 2 > end) return null;
            int nm = U8(d + p), ns = U8(d + p + 1);
            p += 2;
            if (nm > 8 || ns > 8 || p + nm + 1 + ns + 1 > end) return null;
            r.Engineering = true;
            r.MoveGates = new int[nm + 1];
            for (int g = 0; g <= nm; g++) r.MoveGates[g] = U8(d + p + g);
            p += nm + 1;
            r.StillGates = new int[ns + 1];
            for (int g = 0; g <= ns; g++) r.StillGates[g] = U8(d + p + g);
            p += ns + 1;
            if (end - p >= 2)
            {
                r.Light = U8(d + p);
                r.Out = U8(d + p + 1);
            }
        }
        return r;
    }

    public static string? CommandName(int cmd) => cmd switch
    {
        0x00FF => "вход в режим настройки",
        0x00FE => "выход из режима настройки",
        0x0060 => "дальность и задержка",
        0x0061 => "чтение параметров",
        0x0062 => "инженерный режим вкл.",
        0x0063 => "инженерный режим выкл.",
        0x0064 => "чувствительность ворот",
        0x00A0 => "версия прошивки",
        0x00A1 => "скорость порта",
        0x00A2 => "заводские настройки",
        0x00A3 => "перезапуск",
        0x00A4 => "Bluetooth",
        0x00A5 => "MAC-адрес",
        0x00AA => "разрешение ворот (запись)",
        0x00AB => "разрешение ворот (чтение)",
        0x00AD => "OUT и освещённость (запись)",
        0x00AE => "OUT и освещённость (чтение)",
        _ => null,
    };
}
