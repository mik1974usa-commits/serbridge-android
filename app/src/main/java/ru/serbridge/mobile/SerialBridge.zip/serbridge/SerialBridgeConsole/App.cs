using System.Globalization;
using System.Net.Sockets;
using System.Text;

namespace SerialBridgeConsole;

/// <summary>
/// Логика программы: сетевой цикл (приём от моста, переподключение) в фоне,
/// ввод пользователя и локальные команды — в основном потоке.
/// </summary>
sealed class App
{
    readonly Options _opt;
    readonly Terminal _ui;
    readonly CancellationTokenSource _cts = new();
    readonly object _netLock = new();
    readonly object _logLock = new();
    readonly object _hostLock = new();     // смена адреса: сетевой поток и команда :connect
    readonly Decoder _decoder = Encoding.UTF8.GetDecoder();   // собирает UTF-8 символы, разрезанные между пакетами
    readonly char[] _chars = new char[8200];

    string? _host;                   // текущий мост (под _hostLock)
    bool _hostFromDiscovery;
    int _dataPort, _ctrlPort, _meterPort;
    readonly Meter _meter;
    readonly AuxStream _aux;
    TcpClient? _tcp;
    NetworkStream? _stream;
    volatile bool _switching;        // разрыв сделан намеренно (:connect)
    volatile bool _wake;             // прервать паузу перед переподключением
    volatile bool _decoderReset;
    volatile bool _hex;
    string _eol;
    string? _lastWarning;

    StreamWriter? _log;
    string? _logPath;
    bool _logAtLineStart = true;

    public App(Options opt)
    {
        _opt = opt;
        _host = opt.Host;
        _dataPort = opt.DataPort;
        _ctrlPort = opt.CtrlPort;
        _meterPort = opt.MeterPort;
        _eol = opt.Eol;
        _ui = new Terminal { Timestamps = opt.Timestamps };
        _meter = new Meter(_ui, () =>
        {
            lock (_hostLock) return (_host, _meterPort);
        });
        _aux = new AuxStream(_ui, () => CurrentHost, line => LogLine("", line));
        _meter.Extra = _aux.PanelSegments;
        _aux.PanelChanged = _meter.Refresh;
    }

    public int Run()
    {
        SetTitle("поиск моста");
        _ui.Info("SerialBridge — консоль беспроводного моста UART.  :help — команды,  Ctrl+C или :q — выход");
        if (_opt.LogFile != null) StartLog(_opt.LogFile);
        _ui.Info(_host == null ? "Поиск моста в сети…" : $"Подключение к {_host}…");

        Task net = Task.Run(() => NetLoopAsync(_cts.Token));
        Task meter = Task.Run(() => _meter.RunAsync(_cts.Token));
        Task watch = Task.Run(() => _meter.WatchAsync(_cts.Token));
        Task aux = Task.Run(() => _aux.RunAsync(_cts.Token));
        Task auxWatch = Task.Run(() => _aux.WatchAsync(_cts.Token));

        while (true)
        {
            string? line = _ui.ReadLine();
            if (line == null || !HandleLine(line)) break;
        }

        _cts.Cancel();
        CloseConnection();
        _meter.Reconnect();
        _aux.Reconnect();
        try { Task.WaitAll(new[] { net, meter, watch, aux, auxWatch }, 1500); } catch { }
        StopLog(quiet: true);
        _meter.StopCsv(quiet: true);
        _ui.Shutdown();
        return 0;
    }

    // ================================================================ сеть

    async Task NetLoopAsync(CancellationToken ct)
    {
        int failures = 0;
        try
        {
            while (!ct.IsCancellationRequested)
            {
                string? host = CurrentHost;
                if (host == null)
                {
                    List<BridgeInfo> list = await Bridge.DiscoverAsync(_opt.DiscoveryPort, ct: ct);
                    if (list.Count == 0)
                    {
                        WarnOnce("Мост не найден в сети. Продолжаю поиск… (адрес можно задать: :connect <IP>)");
                        await PauseAsync(3000, ct);
                        continue;
                    }
                    if (list.Count > 1)
                    {
                        _ui.Info("Найдено несколько мостов:");
                        PrintBridges(list);
                        _ui.Info($"Подключаюсь к первому. Выбрать другой: :connect <IP>");
                    }
                    BridgeInfo b = list[0];
                    lock (_hostLock)
                    {
                        if (_host != null) continue;   // пока шёл поиск, адрес задали командой :connect
                        host = b.Address;
                        _host = host;
                        _hostFromDiscovery = true;
                        _dataPort = b.DataPort;
                        _ctrlPort = b.CtrlPort;
                        _meterPort = b.MeterPort;
                    }
                }

                bool connected = false;
                TcpClient? tcp = null;
                try
                {
                    // Сначала состояние моста: сколько вывода накоплено, не было ли потерь
                    Dictionary<string, string> st =
                        Bridge.ParseKeyValues(await Bridge.CommandAsync(host, _ctrlPort, "status", ct: ct));

                    tcp = new TcpClient { NoDelay = true };
                    Bridge.ConfigureKeepAlive(tcp.Client);
                    using (var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct))
                    {
                        timeout.CancelAfter(4000);
                        await tcp.ConnectAsync(host, _dataPort, timeout.Token);
                    }
                    NetworkStream stream = tcp.GetStream();
                    lock (_netLock)
                    {
                        if (CurrentHost != host)          // пока подключались, выбрали другой мост
                        {
                            _switching = true;
                            throw new IOException("адрес изменён");
                        }
                        _tcp = tcp;
                        _stream = stream;
                    }
                    connected = true;
                    failures = 0;
                    _switching = false;
                    _lastWarning = null;
                    _decoderReset = true;
                    ReportConnected(host, st);

                    var buf = new byte[4096];
                    while (true)
                    {
                        int n = await stream.ReadAsync(buf, ct);
                        if (n == 0) throw new IOException("мост закрыл соединение");
                        OnData(buf, n);
                    }
                }
                catch (OperationCanceledException) when (ct.IsCancellationRequested)
                {
                    break;
                }
                catch (Exception ex)
                {
                    if (ct.IsCancellationRequested) break;
                    if (_switching)
                    {
                        _switching = false;
                    }
                    else if (connected)
                    {
                        _ui.Warn($"Связь потеряна ({Describe(ex)}). Переподключение…");
                        SetTitle("нет связи");
                    }
                    else
                    {
                        failures++;
                        WarnOnce($"Нет связи с {host}: {Describe(ex)}. Повторяю…");
                        // Адрес из автопоиска мог смениться (DHCP) — ищем мост заново
                        if (failures >= 3)
                        {
                            lock (_hostLock)
                            {
                                if (_hostFromDiscovery && _host == host)
                                {
                                    _host = null;
                                    failures = 0;
                                }
                            }
                        }
                    }
                }
                finally
                {
                    CloseConnection();
                    tcp?.Dispose();
                }

                await PauseAsync(2000, ct);
            }
        }
        catch (OperationCanceledException)
        {
            // выход из программы
        }
    }

    string? CurrentHost
    {
        get { lock (_hostLock) return _host; }
    }

    void ReportConnected(string host, Dictionary<string, string> st)
    {
        string name = st.GetValueOrDefault("name") ?? "мост";
        string baud = st.GetValueOrDefault("baud") ?? "?";
        _ui.Info($"Подключено: {name} ({host}), UART {baud} бод");
        if (long.TryParse(st.GetValueOrDefault("pending"), out long pending) && pending > 0)
            _ui.Info($"Далее — {pending} байт вывода, накопленного мостом, пока консоль не была подключена:");
        if (long.TryParse(st.GetValueOrDefault("lost"), out long lost) && lost > 0)
            _ui.Warn($"Буфер моста переполнялся: более ранние {lost} байт потеряны.");
        SetTitle($"{name} ({host}), {baud} бод");
    }

    void OnData(byte[] buf, int n)
    {
        if (_hex)
        {
            for (int i = 0; i < n; i += 16)
            {
                string line = HexLine(buf, i, Math.Min(16, n - i));
                _ui.Line(line, ConsoleColor.Gray);
                LogLine("", line);
            }
            return;
        }

        if (_decoderReset)
        {
            _decoder.Reset();
            _decoderReset = false;
        }
        int count = _decoder.GetChars(buf, 0, n, _chars, 0, flush: false);
        if (count == 0) return;
        string text = new string(_chars, 0, count);
        _ui.WriteMcu(text);
        LogMcu(text);
    }

    void CloseConnection()
    {
        lock (_netLock)
        {
            try { _stream?.Dispose(); } catch { }
            try { _tcp?.Dispose(); } catch { }
            _stream = null;
            _tcp = null;
        }
    }

    async Task PauseAsync(int ms, CancellationToken ct)
    {
        long end = Environment.TickCount64 + ms;
        while (!_wake && Environment.TickCount64 < end)
            await Task.Delay(100, ct);
        _wake = false;
    }

    void WarnOnce(string message)
    {
        if (message == _lastWarning) return;
        _lastWarning = message;
        _ui.Warn(message);
    }

    static string Describe(Exception ex) => ex switch
    {
        SocketException se => se.SocketErrorCode switch
        {
            SocketError.ConnectionRefused => "соединение отклонено",
            SocketError.TimedOut => "превышено время ожидания",
            SocketError.HostUnreachable or SocketError.NetworkUnreachable => "узел недоступен",
            SocketError.ConnectionReset => "соединение сброшено",
            SocketError.HostNotFound => "имя не найдено",
            _ => se.Message,
        },
        IOException { InnerException: SocketException inner } => Describe(inner),
        OperationCanceledException => "превышено время ожидания",
        _ => ex.Message,
    };

    // ================================================================ ввод пользователя

    /// <returns>false — завершить программу</returns>
    bool HandleLine(string line)
    {
        if (line.StartsWith("::"))
        {
            SendText(line[1..]);          // "::текст" отправляет ":текст" в МК
            return true;
        }
        if (line.StartsWith(':')) return LocalCommand(line[1..].Trim());
        SendText(line);
        return true;
    }

    void SendText(string text)
    {
        if (SendBytes(Encoding.UTF8.GetBytes(text + _eol)))
        {
            _ui.Echo(text);
            LogLine("» ", text);
        }
    }

    bool SendBytes(byte[] data)
    {
        if (_meter.TargetPowered == false)
        {
            _ui.Warn("МК без питания (нет напряжения на XP2.3) — не отправлено.");
            return false;
        }
        string? error = null;
        lock (_netLock)
        {
            if (_stream == null)
            {
                error = "Нет связи с мостом — не отправлено.";
            }
            else
            {
                try { _stream.Write(data); }
                catch (Exception ex) { error = $"Ошибка отправки: {Describe(ex)}"; }
            }
        }
        if (error != null) _ui.Warn(error);
        return error == null;
    }

    bool LocalCommand(string cmdLine)
    {
        string[] parts = cmdLine.Split(' ', 2, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        string cmd = parts.Length > 0 ? parts[0].ToLowerInvariant() : "";
        string arg = parts.Length > 1 ? parts[1] : "";

        switch (cmd)
        {
            case "q": case "quit": case "exit":
                return false;
            case "": case "?": case "help":
                PrintHelp();
                break;
            case "baud":
                BaudCommand(arg);
                break;
            case "status":
                ShowStatus();
                break;
            case "eol":
                EolCommand(arg);
                break;
            case "time":
                _ui.Timestamps = !_ui.Timestamps;
                _ui.Info($"Метки времени: {OnOff(_ui.Timestamps)}");
                break;
            case "hex":
                _hex = !_hex;
                _decoderReset = true;
                _ui.Info($"Шестнадцатеричный вывод: {OnOff(_hex)}");
                break;
            case "tx":
                SendHexCommand(arg);
                break;
            case "log":
                if (_log != null && arg.Length == 0) StopLog(quiet: false);
                else StartLog(arg.Length > 0 ? arg : $"serial_{DateTime.Now:yyyyMMdd_HHmmss}.log");
                break;
            case "clear": case "cls":
                _ui.Clear();
                break;
            case "find":
                FindCommand();
                break;
            case "connect":
                ConnectCommand(arg);
                break;
            case "v":
                _meter.Command(arg, RemoteCommand);
                break;
            case "reset":
                RemoteCommand(arg.Length == 0 ? "reset" : "reset " + arg);
                break;
            case "aux":
                RemoteCommand(arg.Length == 0 ? "aux" : "aux " + arg);
                break;
            case "auxview":
                _aux.Command(arg);
                _meter.Refresh();
                break;
            case "bridge":
                if (arg.Length == 0) _ui.Warn("Укажите команду моста, например :bridge help");
                else RemoteCommand(arg);
                break;
            default:
                _ui.Warn($"Неизвестная команда :{cmd}. Список — :help");
                break;
        }
        return true;
    }

    void PrintHelp()
    {
        _ui.Info("Строка без двоеточия отправляется в МК (как в мониторе порта). Команды консоли:");
        string[] help =
        {
            "  :baud [N]          скорость UART моста (без N — показать текущую)",
            "  :status            состояние моста и консоли",
            "  :eol lf|crlf|cr|none  окончание отправляемой строки (сейчас: " + EolName(_eol) + ")",
            "  :time              метки времени у строк вкл/выкл",
            "  :hex               шестнадцатеричный вывод вкл/выкл",
            "  :tx 48 65 0A       отправить байты в hex",
            "  :log [файл]        начать/остановить запись сеанса",
            "  :clear             очистить экран",
            "  :find              найти мосты в сети",
            "  :connect <адрес>   подключиться к другому мосту",
            "  :reset [мс]        сбросить отлаживаемый МК (линия RESET, XP2.5), по умолчанию 100 мс",
            "  :aux [0|1|pulse мс] доп. линия XP2.6: прочитать / притянуть к 0 / отпустить / импульс 0",
            "  :aux uart 256000   XP2.6 — второй приёмник (TX другого устройства, порт 2327); :aux off — обратно",
            "  :auxview auto|text|hex|ld2410 [с]|off  как показывать второй поток (строки «AUX›»)",
            "  :bridge <команда>  команда мосту: ssid, pass, name, restart, tsense on|off, help",
            "  :bridge tcal 4.98  подогнать показание питания МК под мультиметр (tcal reset — сброс)",
            "Панель напряжений (ADS1115):",
            "  :v                 показать/скрыть панель над строкой ввода",
            "  :v list            каналы: имена, коэффициенты, поправки, пороги",
            "  :v rate 5          обновлений в секунду (1…20)",
            "  :v name 1 +5V      имя канала",
            "  :v cal 1 4.98      подстроить канал 1 под показание мультиметра (:v cal 1 reset — сброс)",
            "  :v k 3 4.9         коэффициент делителя канала (R1+R2)/R2",
            "  :v on 2 / :v off 2 включить/выключить канал",
            "  :v alarm 1 <4.75 >5.25   пороги тревоги (:v alarm 1 off — снять)",
            "  :v reset           сбросить минимумы и максимумы;  :v mm — показывать их или нет",
            "  :v csv [файл]      запись напряжений в CSV (для Excel)",
            "  ::текст            отправить в МК строку, начинающуюся с ':'",
            "  :q                 выход (или Ctrl+C)",
            "Клавиши: ←/→ Home End — редактирование, ↑/↓ — история, Esc — очистить строку.",
        };
        foreach (string h in help) _ui.Line(h, ConsoleColor.Gray);
    }

    void BaudCommand(string arg)
    {
        if (arg.Length > 0 && !uint.TryParse(arg, out _))
        {
            _ui.Warn("Скорость — целое число, например :baud 57600");
            return;
        }
        string? reply = RemoteCommand(arg.Length == 0 ? "baud" : "baud " + arg);
        if (reply != null && arg.Length > 0 && reply.StartsWith("OK"))
            SetTitle($"{CurrentHost}, {arg} бод");
    }

    /// <summary>Команда на порт управления; ответ печатается (если print). Возвращает ответ или null.</summary>
    string? RemoteCommand(string command, bool print = true)
    {
        string? host = CurrentHost;
        if (host == null)
        {
            _ui.Warn("Мост ещё не найден.");
            return null;
        }
        try
        {
            string reply = Bridge.CommandAsync(host, _ctrlPort, command).GetAwaiter().GetResult();
            if (print && reply.StartsWith("OK")) _ui.Info("Мост: " + reply[2..].Trim());
            else if (print) _ui.Warn("Мост: " + reply);
            return reply;
        }
        catch (Exception ex)
        {
            _ui.Warn($"Мост не ответил: {Describe(ex)}");
            return null;
        }
    }

    void ShowStatus()
    {
        string? host = CurrentHost;
        bool online;
        lock (_netLock) online = _stream != null;
        _ui.Info($"Консоль: {(online ? "подключена к " + host : "нет связи")}; окончание строки {EolName(_eol)}; " +
                 $"метки времени {OnOff(_ui.Timestamps)}; hex {OnOff(_hex)}; лог {(_logPath ?? "выкл")}");
        if (host == null) return;

        try
        {
            var st = Bridge.ParseKeyValues(Bridge.CommandAsync(host, _ctrlPort, "status").GetAwaiter().GetResult());
            string V(string key) => st.GetValueOrDefault(key) ?? "?";
            string rssi = V("rssi") == "0" ? "" : $", сигнал {V("rssi")} дБм";
            _ui.Info($"Мост: {V("name")}, режим {V("mode")}, IP {V("ip")}{rssi}");
            if (st.ContainsKey("meters"))
                _ui.Info($"Подключено клиентов: поток данных {V("client")}, измерения {V("meters")}");
            _ui.Info($"UART: {V("baud")} бод; от МК принято {V("rx")} байт, в МК передано {V("tx")} байт; " +
                     $"в буфере {V("pending")} байт, потеряно {V("lost")} байт");
            string uptime = long.TryParse(V("uptime"), out long sec)
                ? TimeSpan.FromSeconds(sec).ToString(@"d\.hh\:mm\:ss", CultureInfo.InvariantCulture)
                : "?";
            _ui.Info($"Питание МК: {_meter.TargetDescription}");
            if (V("auxmode") == "uart")
            {
                _ui.Info($"AUX (XP2.6): приём UART {V("auxbaud")} бод; принято {V("auxrx")} байт, " +
                         $"ошибок кадра {V("auxerr")}, переполнений {V("auxovf")}; клиентов {V("auxcl")}");
                if (_aux.LdSummary() is string ld) _ui.Info(ld);
            }
            else if (st.ContainsKey("aux"))
            {
                _ui.Info($"AUX (XP2.6): {V("aux")}" + (V("auxmode") == "low" ? " — мост тянет к нулю" : " — отпущена"));
            }
            _ui.Info($"Работает {uptime}; свободно памяти {V("heap")} байт; АЦП: {V("adc")}, сбоев I2C {V("adcerr")}" +
                     (_meter.CsvPath is string csv ? $"; CSV: {csv}" : ""));
        }
        catch (Exception ex)
        {
            _ui.Warn($"Мост не ответил: {Describe(ex)}");
        }
    }

    void EolCommand(string arg)
    {
        if (arg.Length == 0)
        {
            _ui.Info($"Окончание строки: {EolName(_eol)}");
            return;
        }
        string? eol = ParseEol(arg);
        if (eol == null)
        {
            _ui.Warn("Варианты: lf, crlf, cr, none");
            return;
        }
        _eol = eol;
        _ui.Info($"Окончание строки: {EolName(_eol)}");
    }

    public static string? ParseEol(string s) => s.ToLowerInvariant() switch
    {
        "lf" or "nl" or "\\n" => "\n",
        "crlf" or "\\r\\n" => "\r\n",
        "cr" or "\\r" => "\r",
        "none" or "no" => "",
        _ => null,
    };

    static string EolName(string eol) => eol switch
    {
        "\n" => "LF (\\n)",
        "\r\n" => "CRLF (\\r\\n)",
        "\r" => "CR (\\r)",
        _ => "нет",
    };

    static string OnOff(bool b) => b ? "вкл" : "выкл";

    void SendHexCommand(string arg)
    {
        var bytes = new List<byte>();
        foreach (string t in arg.Split(new[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries))
        {
            string h = t.StartsWith("0x", StringComparison.OrdinalIgnoreCase) ? t[2..] : t;
            if (!byte.TryParse(h, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out byte b))
            {
                _ui.Warn($"Не hex-байт: {t}. Пример: :tx 48 65 6C 6C 6F 0A");
                return;
            }
            bytes.Add(b);
        }
        if (bytes.Count == 0)
        {
            _ui.Warn("Пример: :tx 48 65 6C 6C 6F 0A");
            return;
        }
        if (SendBytes(bytes.ToArray()))
        {
            string shown = string.Join(" ", bytes.Select(b => b.ToString("X2")));
            _ui.Echo("[hex] " + shown);
            LogLine("» [hex] ", shown);
        }
    }

    void FindCommand()
    {
        _ui.Info("Поиск мостов…");
        List<BridgeInfo> list = Bridge.DiscoverAsync(_opt.DiscoveryPort).GetAwaiter().GetResult();
        if (list.Count == 0)
        {
            _ui.Warn("Мосты не найдены. Проверьте, что компьютер и мост в одной сети.");
            return;
        }
        PrintBridges(list);
        _ui.Info("Подключиться: :connect <IP>");
    }

    void PrintBridges(List<BridgeInfo> list)
    {
        foreach (BridgeInfo b in list)
        {
            string busy = b.Clients > 0 ? $", подключено клиентов: {b.Clients}" : "";
            string adc = b.Adc == "none" ? "" : $", АЦП {b.Adc}";
            string aux = b.AuxBaud > 0 ? $", приём на XP2.6 {b.AuxBaud} бод" : "";
            _ui.Line($"  {b.Name,-16} {b.Address,-15}  UART {b.Baud} бод, режим {b.Mode}{adc}{aux}{busy}", ConsoleColor.Gray);
        }
    }

    void ConnectCommand(string arg)
    {
        if (arg.Length == 0)
        {
            _ui.Warn("Укажите адрес: :connect 192.168.1.50 (или serbridge.local)");
            return;
        }
        _ui.Info($"Подключение к {arg}…");
        lock (_netLock) _switching = _stream != null;
        lock (_hostLock)
        {
            _host = arg;
            _hostFromDiscovery = false;
            _dataPort = _opt.DataPort;
            _ctrlPort = _opt.CtrlPort;
            _meterPort = _opt.MeterPort;
        }
        _lastWarning = null;
        _wake = true;
        CloseConnection();
        _meter.Reconnect();
        _aux.Reconnect();
    }

    static string HexLine(byte[] buf, int offset, int count)
    {
        var sb = new StringBuilder(16 * 3 + 20);
        for (int i = 0; i < 16; i++)
            sb.Append(i < count ? buf[offset + i].ToString("X2") + " " : "   ");
        sb.Append(" |");
        for (int i = 0; i < count; i++)
        {
            byte b = buf[offset + i];
            sb.Append(b is >= 0x20 and < 0x7F ? (char)b : '.');
        }
        sb.Append('|');
        return sb.ToString();
    }

    void SetTitle(string state)
    {
        try { Console.Title = "SerialBridge — " + state; } catch { }
    }

    // ================================================================ журнал

    void StartLog(string path)
    {
        try
        {
            var writer = new StreamWriter(path, append: true, new UTF8Encoding(false)) { AutoFlush = true };
            lock (_logLock)
            {
                _log?.Dispose();
                _log = writer;
                _logPath = Path.GetFullPath(path);
                _logAtLineStart = true;
                _log.WriteLine($"===== сеанс {DateTime.Now:yyyy-MM-dd HH:mm:ss} =====");
            }
            _ui.Info($"Запись в файл: {_logPath}");
        }
        catch (Exception ex)
        {
            _ui.Warn($"Не удалось открыть файл журнала: {ex.Message}");
        }
    }

    void StopLog(bool quiet)
    {
        string? path;
        lock (_logLock)
        {
            path = _logPath;
            _log?.Dispose();
            _log = null;
            _logPath = null;
        }
        if (!quiet && path != null) _ui.Info($"Запись остановлена: {path}");
    }

    static string Stamp() => DateTime.Now.ToString("[HH:mm:ss.fff] ");

    void LogMcu(string text)
    {
        lock (_logLock)
        {
            if (_log == null) return;
            var sb = new StringBuilder(text.Length + 32);
            foreach (char c in text)
            {
                if (c == '\r') continue;
                if (c == '\n')
                {
                    sb.Append(Environment.NewLine);
                    _logAtLineStart = true;
                    continue;
                }
                if (char.IsControl(c) && c != '\t') continue;
                if (_logAtLineStart)
                {
                    sb.Append(Stamp());
                    _logAtLineStart = false;
                }
                sb.Append(c);
            }
            _log.Write(sb.ToString());
        }
    }

    void LogLine(string prefix, string text)
    {
        lock (_logLock)
        {
            if (_log == null) return;
            if (!_logAtLineStart) _log.WriteLine();
            _log.WriteLine(Stamp() + prefix + text);
            _logAtLineStart = true;
        }
    }
}
