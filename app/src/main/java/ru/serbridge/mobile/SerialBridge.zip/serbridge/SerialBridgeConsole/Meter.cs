using System.Globalization;
using System.Net.Sockets;
using System.Text;

namespace SerialBridgeConsole;

/// <summary>
/// Панель напряжений: принимает поток измерений моста (порт 2326), показывает его строкой
/// над строкой ввода, следит за порогами и пишет CSV.
/// Формат строк моста:  H adc=ADS1115 rate=5 on=1111 n1=… n2=…   /   V t=… 1=ср:мин:макс …   /   E noadc
///                     T vcc=4.98 pwr=1 sense=1  (питание отлаживаемого МК на XP2.3)
/// </summary>
sealed class Meter
{
    const int N = 4;
    static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

    readonly Terminal _ui;
    readonly Func<(string? Host, int Port)> _target;
    readonly object _lock = new();

    readonly string[] _names = { "ВХ1", "ВХ2", "ВХ3", "ВХ4" };
    readonly bool[] _on = { true, true, true, true };
    readonly double?[] _value = new double?[N];
    readonly double?[] _sessMin = new double?[N];
    readonly double?[] _sessMax = new double?[N];
    readonly double?[] _alarmLow = new double?[N];
    readonly double?[] _alarmHigh = new double?[N];
    readonly bool[] _inAlarm = new bool[N];

    string _adc = "?";
    bool _hasData;
    bool _noAdcReported, _ads1015Reported;
    bool _adcLostEpisode;     // АЦП работал и перестал отвечать — сообщить, когда вернётся
    DateTime _lastData = DateTime.MinValue;
    double? _tVcc;            // питание МК, В; null — мост не сообщал (старая прошивка или нет связи)
    bool? _tPwr;              // есть ли питание у МК (по решению моста)
    bool _tSense = true;      // мост следит за питанием МК
    DateTime _lastT = DateTime.MinValue;
    bool _visible = true;
    bool _showMinMax = true;
    TcpClient? _tcp;

    StreamWriter? _csv;
    string? _csvPath;

    public Meter(Terminal ui, Func<(string? Host, int Port)> target)
    {
        _ui = ui;
        _target = target;
    }

    public string AdcName { get { lock (_lock) return _adc; } }

    /// <summary>Дополнительные сегменты панели (состояние радара на XP2.6); пустой список — нет.</summary>
    public Func<List<Segment>>? Extra;

    /// <summary>false — у МК нет питания и мост отключил линию TX; null — неизвестно.</summary>
    public bool? TargetPowered
    {
        get
        {
            lock (_lock)
                return (DateTime.Now - _lastT).TotalSeconds <= 3 ? _tPwr : null;
        }
    }

    /// <summary>Строка для :status, например «4,98 В, связь включена».</summary>
    public string TargetDescription
    {
        get
        {
            lock (_lock)
            {
                if (_tVcc is not double v || (DateTime.Now - _lastT).TotalSeconds > 3) return "нет данных";
                if (!_tSense) return $"контроль выключен (tsense off), {F2(v)} В";
                return _tPwr == true ? $"{F2(v)} В, связь включена" : $"без питания ({F2(v)} В), линии TX и RESET отключены";
            }
        }
    }

    // ============================================================ сеть

    public async Task RunAsync(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            (string? host, int port) = _target();
            if (host == null)
            {
                if (!await Pause(1000, ct)) break;
                continue;
            }
            try
            {
                using var tcp = new TcpClient { NoDelay = true };
                Bridge.ConfigureKeepAlive(tcp.Client);
                using (var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct))
                {
                    timeout.CancelAfter(4000);
                    await tcp.ConnectAsync(host, port, timeout.Token);
                }
                lock (_lock) _tcp = tcp;
                using var reader = new StreamReader(tcp.GetStream(), Encoding.UTF8);
                while (_target().Host == host)
                {
                    // Мост шлёт строку хотя бы раз в секунду. Тишина дольше 4 с — соединение повисло
                    // (keepalive этого не замечает): рвём его и подключаемся заново.
                    string? line;
                    using (var lineCts = CancellationTokenSource.CreateLinkedTokenSource(ct))
                    {
                        lineCts.CancelAfter(4000);
                        try
                        {
                            line = await reader.ReadLineAsync(lineCts.Token);
                        }
                        catch (OperationCanceledException) when (!ct.IsCancellationRequested)
                        {
                            _ui.Warn(DateTime.Now.ToString("[HH:mm:ss.fff] ") +
                                     "Поток измерений молчит 4 с — переподключаюсь");
                            break;
                        }
                    }
                    if (line == null) break;
                    OnLine(line.Trim());
                }
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested)
            {
                break;
            }
            catch (Exception)
            {
                // нет связи или старая прошивка без порта измерений — тихо пробуем позже
            }
            finally
            {
                lock (_lock)
                {
                    _tcp = null;
                    _hasData = false;
                    _tVcc = null;
                    _tPwr = null;
                }
                Refresh();
            }
            if (!await Pause(2000, ct)) break;
        }
    }

    /// <summary>Раз в секунду: если данные перестали приходить — показать это на панели.</summary>
    public async Task WatchAsync(CancellationToken ct)
    {
        while (await Pause(1000, ct)) Refresh();
    }

    /// <summary>Сменился мост — оборвать текущее соединение.</summary>
    public void Reconnect()
    {
        lock (_lock)
        {
            try { _tcp?.Dispose(); } catch { }
        }
    }

    static async Task<bool> Pause(int ms, CancellationToken ct)
    {
        try
        {
            await Task.Delay(ms, ct);
            return true;
        }
        catch (OperationCanceledException)
        {
            return false;
        }
    }

    void OnLine(string line)
    {
        if (line.StartsWith("H ")) OnHeader(Bridge.ParseKeyValues(line));
        else if (line.StartsWith("V ")) OnValues(line);
        else if (line.StartsWith("E noadc")) OnNoAdc();
        else if (line.StartsWith("T ")) OnTarget(Bridge.ParseKeyValues(line));
    }

    void OnTarget(Dictionary<string, string> kv)
    {
        if (!double.TryParse(kv.GetValueOrDefault("vcc"), NumberStyles.Float, Inv, out double vcc)) return;
        bool pwr = kv.GetValueOrDefault("pwr") == "1";
        bool sense = kv.GetValueOrDefault("sense") != "0";
        bool? before;
        lock (_lock)
        {
            before = _tPwr;
            _tVcc = vcc;
            _tPwr = pwr;
            _tSense = sense;
            _lastT = DateTime.Now;
        }
        string stamp = DateTime.Now.ToString("[HH:mm:ss.fff] ");
        if (before == null && !pwr)
            _ui.Warn("МК без питания (нет напряжения на XP2.3): мост отключил линии TX и RESET.");
        else if (before == false && pwr)
            _ui.Line($"{stamp}Питание МК появилось: {F2(vcc)} В — связь включена", ConsoleColor.Green);
        else if (before == true && !pwr)
            _ui.Warn($"{stamp}Питание МК пропало ({F2(vcc)} В) — линии TX и RESET отключены");
        Refresh();
    }

    void OnHeader(Dictionary<string, string> kv)
    {
        bool warn1015 = false;
        lock (_lock)
        {
            _adc = kv.GetValueOrDefault("adc") ?? "?";
            string on = kv.GetValueOrDefault("on") ?? "1111";
            for (int i = 0; i < N; i++)
            {
                if (i < on.Length) _on[i] = on[i] == '1';
                if (kv.TryGetValue($"n{i + 1}", out string? name) && name.Length > 0) _names[i] = name;
                if (!_on[i]) _value[i] = null;
            }
            if (_adc == "ADS1015" && !_ads1015Reported)
            {
                _ads1015Reported = true;
                warn1015 = true;
            }
        }
        if (warn1015)
            _ui.Warn("Модуль АЦП похож на ADS1015 (12 бит), а не на ADS1115: разрешение в 16 раз хуже.");
        Refresh();
    }

    void OnNoAdc()
    {
        bool report, wasData;
        lock (_lock)
        {
            wasData = _hasData;
            _hasData = false;
            _adc = "none";
            report = !_noAdcReported;
            _noAdcReported = true;
            if (wasData) _adcLostEpisode = true;
        }
        if (report && wasData)
            _ui.Warn(DateTime.Now.ToString("[HH:mm:ss.fff] ") +
                     "АЦП ADS1115 перестал отвечать — мост восстанавливает шину I2C");
        else if (report)
            _ui.Info("Модуль ADS1115 не найден (I2C: D21, D22) — напряжения ВХ1…ВХ4 не показываются.");
        Refresh();
    }

    void OnValues(string line)
    {
        var events = new List<(string Text, bool Bad)>();
        var csv = new string?[N * 3];

        lock (_lock)
        {
            if (_adcLostEpisode) events.Add(("АЦП ADS1115 снова на связи", false));
            _adcLostEpisode = false;
            _noAdcReported = false;
            _hasData = true;
            _lastData = DateTime.Now;

            foreach (string token in line.Split(' ', StringSplitOptions.RemoveEmptyEntries))
            {
                int eq = token.IndexOf('=');
                if (eq <= 0 || !int.TryParse(token[..eq], NumberStyles.Integer, Inv, out int ch)) continue;
                int i = ch - 1;
                if (i < 0 || i >= N) continue;
                string[] p = token[(eq + 1)..].Split(':');
                if (p.Length != 3 ||
                    !double.TryParse(p[0], NumberStyles.Float, Inv, out double avg) ||
                    !double.TryParse(p[1], NumberStyles.Float, Inv, out double min) ||
                    !double.TryParse(p[2], NumberStyles.Float, Inv, out double max)) continue;

                _value[i] = avg;
                if (_sessMin[i] == null || min < _sessMin[i]) _sessMin[i] = min;
                if (_sessMax[i] == null || max > _sessMax[i]) _sessMax[i] = max;

                csv[i * 3] = avg.ToString("0.0000", CultureInfo.CurrentCulture);
                csv[i * 3 + 1] = min.ToString("0.0000", CultureInfo.CurrentCulture);
                csv[i * 3 + 2] = max.ToString("0.0000", CultureInfo.CurrentCulture);

                // Пороги: по минимуму и максимуму интервала — ловим и короткие провалы
                bool low = _alarmLow[i] is double lo && min < lo;
                bool high = _alarmHigh[i] is double hi && max > hi;
                bool alarm = low || high;
                if (alarm && !_inAlarm[i])
                {
                    string what = low ? $"{F(min)} В < {F(_alarmLow[i]!.Value)} В" : $"{F(max)} В > {F(_alarmHigh[i]!.Value)} В";
                    events.Add(($"!!! {_names[i]}: {what}", true));
                }
                else if (!alarm && _inAlarm[i])
                {
                    events.Add(($"{_names[i]} снова в норме: {F(avg)} В", false));
                }
                _inAlarm[i] = alarm;
            }
        }

        foreach (var (text, bad) in events)
        {
            string stamped = DateTime.Now.ToString("[HH:mm:ss.fff] ") + text;
            if (bad) _ui.Warn(stamped);
            else _ui.Line(stamped, ConsoleColor.Green);
        }
        WriteCsv(csv);
        Refresh();
    }

    static string F(double v) => v.ToString("0.000", CultureInfo.CurrentCulture);
    static string F2(double v) => v.ToString("0.00", CultureInfo.CurrentCulture);

    // ============================================================ панель

    public void Refresh()
    {
        // SetStatus под _lock: более старая панель не перезапишет более новую.
        // Взаимной блокировки нет — Terminal никогда не берёт _lock.
        lock (_lock)
        {
            List<Segment>? segs = null;
            bool tFresh = _tVcc != null && (DateTime.Now - _lastT).TotalSeconds <= 3;
            List<Segment> extra = Extra?.Invoke() ?? new List<Segment>();
            if (_visible && (_hasData || tFresh || extra.Count > 0))
            {
                bool stale = _hasData && (DateTime.Now - _lastData).TotalSeconds > 3;
                // Подробность панели: 2 — мин/макс с тремя знаками, 1 — компактно (два знака,
                // узкие промежутки), 0 — без мин/макс. Берём самую подробную, что влезает в окно.
                for (int detail = _showMinMax ? 2 : 0; ; detail--)
                {
                    segs = Build(stale, detail, tFresh);
                    if (extra.Count > 0)
                    {
                        if (segs.Count > 0) segs.Add(new Segment(detail == 2 ? "   " : "  ", ConsoleColor.Gray));
                        segs.AddRange(extra);
                    }
                    if (detail == 0 || segs.Sum(s => s.Text.Length) <= Terminal.Width - 1) break;
                }
                if (segs.Count == 0) segs = null;
            }
            _ui.SetStatus(segs);
        }
    }

    List<Segment> Build(bool stale, int detail, bool target)
    {
        var segs = new List<Segment>();
        string sep = detail == 2 ? "   " : "  ";
        if (target && _tVcc is double tv)
        {
            segs.Add(new Segment("МК ", ConsoleColor.DarkCyan));
            if (!_tSense) segs.Add(new Segment(F2(tv) + " В", ConsoleColor.Gray));
            else if (_tPwr == true) segs.Add(new Segment(F2(tv) + " В", ConsoleColor.Green));
            else segs.Add(new Segment("без питания", ConsoleColor.Red));
        }
        if (!_hasData) return segs;
        for (int i = 0; i < N; i++)
        {
            if (!_on[i] || _value[i] is not double v) continue;
            if (segs.Count > 0) segs.Add(new Segment(sep, ConsoleColor.Gray));
            segs.Add(new Segment(_names[i] + " ", ConsoleColor.DarkCyan));
            ConsoleColor c = stale ? ConsoleColor.DarkGray : _inAlarm[i] ? ConsoleColor.Red : ConsoleColor.White;
            segs.Add(new Segment(F(v) + " В", c));
            if (detail > 0 && _sessMin[i] is double mn && _sessMax[i] is double mx)
                segs.Add(new Segment(detail == 2 ? $" [{F(mn)}..{F(mx)}]" : $" [{F2(mn)}..{F2(mx)}]",
                                     ConsoleColor.DarkGray));
        }
        if (stale) segs.Add(new Segment("   (нет новых данных)", ConsoleColor.DarkGray));
        return segs;
    }

    // ============================================================ команды :v

    /// <param name="remote">команда мосту; второй параметр — печатать ли ответ</param>
    public void Command(string arg, Func<string, bool, string?> remote)
    {
        string[] p = arg.Split(' ', 3, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        string sub = p.Length > 0 ? p[0].ToLowerInvariant() : "";

        switch (sub)
        {
            case "":
                lock (_lock) _visible = !_visible;
                _ui.Info($"Панель напряжений: {(_visible ? "показана" : "скрыта")}");
                Refresh();
                return;

            case "list":
                ShowList(remote);
                return;

            case "rate":
                if (p.Length < 2 || !int.TryParse(p[1], out int hz) || hz < 1 || hz > 20)
                {
                    _ui.Warn("Пример: :v rate 5  (обновлений в секунду, 1…20)");
                    return;
                }
                remote($"vrate {hz}", true);
                return;

            case "mm":
                lock (_lock) _showMinMax = !_showMinMax;
                Refresh();
                return;

            case "reset":
                lock (_lock)
                {
                    Array.Clear(_sessMin);
                    Array.Clear(_sessMax);
                }
                _ui.Info("Минимумы и максимумы сброшены.");
                Refresh();
                return;

            case "csv":
                if (_csv != null && p.Length < 2) StopCsv(quiet: false);
                else StartCsv(p.Length >= 2 ? arg[(arg.IndexOf(' ') + 1)..].Trim() : $"volts_{DateTime.Now:yyyyMMdd_HHmmss}.csv");
                return;
        }

        // Остальные команды — с номером канала
        if (p.Length < 2 || !int.TryParse(p[1], out int ch) || ch < 1 || ch > N)
        {
            _ui.Warn($"Укажите номер канала 1…{N}. Список команд — :help");
            return;
        }
        string rest = p.Length > 2 ? p[2] : "";

        switch (sub)
        {
            case "on":
            case "off":
                remote($"v{sub} {ch}", true);
                break;

            case "name":
                if (rest.Length == 0 || rest.Contains(' ') || rest.Length > 12)
                {
                    _ui.Warn("Имя без пробелов, до 12 символов. Пример: :v name 1 +5V");
                    return;
                }
                remote($"vname {ch} {rest}", true);
                break;

            case "k":
                if (!TryNumber(rest, out double k))
                {
                    _ui.Warn("Пример: :v k 3 4.9  (коэффициент делителя (R1+R2)/R2)");
                    return;
                }
                remote($"vk {ch} {k.ToString(Inv)}", true);
                break;

            case "cal":
                if (rest.Equals("reset", StringComparison.OrdinalIgnoreCase))
                {
                    remote($"vcal {ch} 1", true);
                }
                else if (TryNumber(rest, out double u))
                {
                    remote($"vcalto {ch} {u.ToString(Inv)}", true);
                }
                else
                {
                    _ui.Warn("Пример: :v cal 1 4.98  — подстроить канал 1 под показание мультиметра");
                }
                break;

            case "alarm":
                SetAlarm(ch - 1, rest);
                break;

            default:
                _ui.Warn($"Неизвестная команда :v {sub}. Список — :help");
                break;
        }
    }

    static bool TryNumber(string s, out double v) =>
        double.TryParse(s.Replace(',', '.'), NumberStyles.Float, Inv, out v) && double.IsFinite(v);

    void SetAlarm(int i, string spec)
    {
        double? low = null, high = null;
        if (!spec.Equals("off", StringComparison.OrdinalIgnoreCase))
        {
            foreach (string t in SplitThresholds(spec))
            {
                if (t.Length < 2 || !TryNumber(t[1..], out double v))
                {
                    _ui.Warn("Пример: :v alarm 1 <4.75 >5.25   или   :v alarm 1 off");
                    return;
                }
                if (t[0] == '<') low = v;
                else high = v;
            }
            if (low == null && high == null)
            {
                _ui.Warn("Пример: :v alarm 1 <4.75 >5.25   или   :v alarm 1 off");
                return;
            }
        }
        string name;
        lock (_lock)
        {
            _alarmLow[i] = low;
            _alarmHigh[i] = high;
            _inAlarm[i] = false;
            name = _names[i];
        }
        if (low == null && high == null) _ui.Info($"{name}: пороги сняты");
        else
            _ui.Info($"{name}: тревога при" +
                     (low is double l ? $" U < {F(l)} В" : "") +
                     (low != null && high != null ? " или" : "") +
                     (high is double h ? $" U > {F(h)} В" : ""));
    }

    /// <summary>"&lt;4.75 &gt;5.25" → ["&lt;4.75", "&gt;5.25"] (пробелы после знака допускаются)</summary>
    static IEnumerable<string> SplitThresholds(string spec)
    {
        string s = spec.Replace(" ", "");
        int start = -1;
        for (int i = 0; i < s.Length; i++)
        {
            if (s[i] is '<' or '>')
            {
                if (start >= 0) yield return s[start..i];
                start = i;
            }
            else if (start < 0)
            {
                yield return s;   // мусор до первого знака — пусть разбор сообщит об ошибке
                yield break;
            }
        }
        if (start >= 0) yield return s[start..];
    }

    void ShowList(Func<string, bool, string?> remote)
    {
        string? reply = remote("vch", false);
        if (reply == null) return;
        if (!reply.StartsWith("OK"))
        {
            _ui.Warn("Мост: " + reply);
            return;
        }
        string[] parts = reply[2..].Split('|', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries);
        _ui.Info("Каналы измерения (" + parts[0] + "):");
        for (int k = 1; k < parts.Length && k <= N; k++)
        {
            int i = k - 1;
            string alarm;
            lock (_lock)
                alarm = (_alarmLow[i] is double l ? $" <{F(l)}" : "") + (_alarmHigh[i] is double h ? $" >{F(h)}" : "");
            _ui.Line($"  {parts[k]}{(alarm.Length > 0 ? "   пороги:" + alarm : "")}", ConsoleColor.Gray);
        }
    }

    // ============================================================ CSV

    void StartCsv(string path)
    {
        try
        {
            bool exists = File.Exists(path);
            var w = new StreamWriter(path, append: true, new UTF8Encoding(true)) { AutoFlush = true };
            string[] names;
            lock (_lock) names = (string[])_names.Clone();
            if (!exists)
            {
                var header = new StringBuilder("время");
                foreach (string n in names) header.Append($";{n};{n} мин;{n} макс");
                w.WriteLine(header);
            }
            lock (_lock)
            {
                _csv?.Dispose();
                _csv = w;
                _csvPath = Path.GetFullPath(path);
            }
            _ui.Info($"Запись напряжений в CSV: {_csvPath}");
        }
        catch (Exception ex)
        {
            _ui.Warn($"Не удалось открыть CSV: {ex.Message}");
        }
    }

    public void StopCsv(bool quiet)
    {
        string? path;
        lock (_lock)
        {
            path = _csvPath;
            _csv?.Dispose();
            _csv = null;
            _csvPath = null;
        }
        if (!quiet && path != null) _ui.Info($"Запись CSV остановлена: {path}");
    }

    public string? CsvPath { get { lock (_lock) return _csvPath; } }

    void WriteCsv(string?[] cells)
    {
        lock (_lock)
        {
            if (_csv == null) return;
            var sb = new StringBuilder(DateTime.Now.ToString("HH:mm:ss.fff", Inv));
            foreach (string? c in cells) sb.Append(';').Append(c);
            try { _csv.WriteLine(sb); } catch (IOException) { }
        }
    }
}
