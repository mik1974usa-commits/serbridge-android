/*
  ESP32Test — проверка беспроводного моста с МК на 3,3 В: ESP32 DevKit на 38 выводов (ESP-32S / WROOM-32).

  Плата в Arduino IDE: «ESP32 Dev Module». Подключение к XP2 моста:
    XP2.1 (к RX МК)    → GPIO16 (RX2)
    XP2.2 (к TX МК)    ← GPIO17 (TX2)
    XP2.3 (Vcc МК)     → 3V3 этой платы   (НЕ 5V и не VIN!)
    XP2.4 (GND)        — GND
    XP2.5 (к RESET МК) → EN этой платы
  Питание — от своего USB. UART0 (GPIO1/3) занят USB-мостом платы, поэтому для связи
  с мостом взят UART2; всё, что уходит в мост, дублируется в USB (монитор порта Arduino IDE).

  Раз в 2 секунды печатает счётчик и время работы. Команды из консоли (окончание LF):
    stop / start     — остановить / возобновить вывод счётчика
    led on / led off — синий светодиод на GPIO2
    info             — причина последнего сброса, частота, свободная память
    flood [N]        — выдать N строк подряд (по умолчанию 500): проверка потока без потерь
    baud N           — сменить скорость UART2; затем в консоли ввести :baud N
    любая другая строка — возвращается обратно («эхо»)
  После :reset в консоли должна появиться строка «ESP32Test: старт».
*/

#include <esp_system.h>

const unsigned long BAUD = 115200;      // = скорость моста (:baud)
const int RX2_PIN = 16;
const int TX2_PIN = 17;
const int LED_PIN = 2;

char line[64];
uint8_t lineLen = 0;
unsigned long lastReport = 0;
bool reporting = true;                  // выводить счётчик (команды stop / start)
unsigned long counter = 0;

void out(const String &s) {             // в мост и в USB одновременно
  Serial2.println(s);
  Serial.println(s);
}

const char *resetReason() {
  switch (esp_reset_reason()) {
    case ESP_RST_POWERON:  return "включение питания или вывод EN (:reset)";
    case ESP_RST_SW:       return "программный (ESP.restart)";
    case ESP_RST_PANIC:    return "ошибка программы (panic)";
    case ESP_RST_INT_WDT:
    case ESP_RST_TASK_WDT:
    case ESP_RST_WDT:      return "сторожевой таймер";
    case ESP_RST_BROWNOUT: return "просадка питания (brownout)";
    case ESP_RST_DEEPSLEEP: return "выход из глубокого сна";
    default:               return "другая";
  }
}

void setup() {
  Serial.begin(115200);
  Serial2.begin(BAUD, SERIAL_8N1, RX2_PIN, TX2_PIN);
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);
  out(String("ESP32Test: старт (сброс: ") + resetReason() + "). Команды: stop, start, led on|off, info, flood [N], baud N");
}

void handleLine(const char *s) {
  if (strcmp(s, "stop") == 0) {
    reporting = false;
    out("Счётчик остановлен (start — продолжить)");
  } else if (strcmp(s, "start") == 0) {
    reporting = true;
    lastReport = millis() - 2000;         // следующее показание — сразу
    out("Счётчик продолжает");
  } else if (strcmp(s, "led on") == 0) {
    digitalWrite(LED_PIN, HIGH);
    out("Светодиод включён");
  } else if (strcmp(s, "led off") == 0) {
    digitalWrite(LED_PIN, LOW);
    out("Светодиод выключен");
  } else if (strcmp(s, "info") == 0) {
    out(String("Сброс: ") + resetReason() + "; CPU " + getCpuFrequencyMhz() + " МГц; свободно " +
        ESP.getFreeHeap() + " байт; работаю " + millis() / 1000 + " с");
  } else if (strncmp(s, "flood", 5) == 0 && (s[5] == '\0' || s[5] == ' ')) {
    long n = s[5] ? atol(s + 6) : 500;
    if (n < 1 || n > 100000) n = 500;
    unsigned long t0 = millis();
    for (long i = 1; i <= n; i++) {
      // 64 символа в строке: номер + проверочный хвост — по нему легко заметить потерю
      Serial2.printf("flood %06ld/%06ld 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghij\n", i, n);
    }
    Serial2.flush();
    out(String("flood: готово, ") + n + " строк за " + (millis() - t0) + " мс");
  } else if (strncmp(s, "baud ", 5) == 0) {
    unsigned long b = strtoul(s + 5, nullptr, 10);
    if (b < 300 || b > 2000000) {
      out("Скорость от 300 до 2000000");
      return;
    }
    out(String("Перехожу на ") + b + " бод — введите в консоли :baud " + b);
    Serial2.flush();
    Serial2.updateBaudRate(b);
  } else {
    out(String("Получено: ") + s);
  }
}

void loop() {
  while (Serial2.available() > 0) {
    char c = Serial2.read();
    if (c == '\r') continue;
    if (c == '\n') {
      line[lineLen] = '\0';
      handleLine(line);
      lineLen = 0;
    } else if (lineLen < sizeof(line) - 1) {
      line[lineLen++] = c;
    }
  }

  if (reporting && millis() - lastReport >= 2000) {
    lastReport = millis();
    out("Счётчик: " + String(++counter) + ", работаю " + String(millis() / 1000) + " с");
  }
}
