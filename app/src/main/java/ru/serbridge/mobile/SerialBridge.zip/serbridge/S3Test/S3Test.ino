/*
  S3Test — проверка беспроводного моста с МК на 3,3 В (ESP32-S3-DevKitC-1).

  Плата в Arduino IDE: «ESP32S3 Dev Module». Подключение к XP2 моста:
    XP2.1 (к RX МК)    → GPIO18  (RX1)
    XP2.2 (к TX МК)    ← GPIO17  (TX1)
    XP2.3 (Vcc МК)     → 3V3 платы S3   (НЕ 5V!)
    XP2.4 (GND)        — GND
    XP2.5 (к RESET МК) → RST (EN) платы S3

  Мост работает с UART1 (Serial1). Обычный Serial идёт в USB, туда же дублируется вывод —
  можно сравнить в мониторе порта Arduino IDE, что видит консоль моста.

  Раз в 2 секунды печатает счётчик и время работы. Команды из консоли (окончание LF):
    stop / start     — остановить / возобновить вывод счётчика
    led on / led off — встроенный RGB-светодиод
    любая другая строка — возвращается обратно («эхо»)
  После :reset в консоли должна появиться строка «S3Test: старт».
*/

const unsigned long BAUD = 115200;      // = скорость моста (:baud)
const int RX1_PIN = 18;
const int TX1_PIN = 17;

char line[64];
uint8_t lineLen = 0;
unsigned long lastReport = 0;
bool reporting = true;                  // выводить счётчик (команды stop / start)
unsigned long counter = 0;

void out(const String &s) {             // в мост и в USB одновременно
  Serial1.println(s);
  Serial.println(s);
}

void led(bool on) {
#ifdef RGB_BUILTIN
  neopixelWrite(RGB_BUILTIN, 0, on ? 32 : 0, 0);   // зелёный, неяркий
#endif
}

void setup() {
  Serial.begin(115200);
  Serial1.begin(BAUD, SERIAL_8N1, RX1_PIN, TX1_PIN);
  led(false);
  out("S3Test: старт. Команды: stop, start, led on, led off");
}

void handleLine(const char *s) {
  if (strcmp(s, "stop") == 0) {
    reporting = false;
    out("Счётчик остановлен (start — продолжить)");
  } else if (strcmp(s, "start") == 0) {
    reporting = true;
    lastReport = millis() - 2000;         // следующее показание — сразу
    out("Счётчик продолжает");
  } else if (strcmp(s, "led on") == 0) {
    led(true);
    out("Светодиод включён");
  } else if (strcmp(s, "led off") == 0) {
    led(false);
    out("Светодиод выключен");
  } else {
    out(String("Получено: ") + s);
  }
}

void loop() {
  while (Serial1.available() > 0) {
    char c = Serial1.read();
    if (c == '\r') continue;
    if (c == '\n') {
      line[lineLen] = '\0';
      handleLine(line);
      lineLen = 0;
    } else if (lineLen < sizeof(line) - 1) {
      line[lineLen++] = c;
    }
  }

  if (reporting && millis() - lastReport >= 2000) {
    lastReport = millis();
    out("Счётчик: " + String(++counter) + ", работаю " + String(millis() / 1000) + " с");
  }
}
