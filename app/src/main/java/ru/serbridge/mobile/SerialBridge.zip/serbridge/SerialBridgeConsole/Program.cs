using System.Text;

namespace SerialBridgeConsole;

/// <summary>Параметры командной строки.</summary>
sealed class Options
{
    public string? Host;
    public int DataPort = Bridge.DefaultDataPort;
    public int CtrlPort = Bridge.DefaultCtrlPort;
    public int DiscoveryPort = Bridge.DefaultDiscoveryPort;
    public int MeterPort = Bridge.DefaultMeterPort;
    public string Eol = "\n";
    public bool Timestamps;
    public string? LogFile;

    public static Options Parse(string[] args)
    {
        var o = new Options();
        for (int i = 0; i < args.Length; i++)
        {
            string a = args[i];
            string Next() => i + 1 < args.Length ? args[++i] : throw new ArgumentException($"После {a} нужно значение");
            switch (a)
            {
                case "-p": case "--port": o.DataPort = ParsePort(Next()); break;
                case "--ctrl": o.CtrlPort = ParsePort(Next()); break;
                case "--udp": o.DiscoveryPort = ParsePort(Next()); break;
                case "--meter": o.MeterPort = ParsePort(Next()); break;
                case "--eol": o.Eol = App.ParseEol(Next()) ?? throw new ArgumentException("--eol: lf, crlf, cr или none"); break;
                case "-t": case "--time": o.Timestamps = true; break;
                case "-l": case "--log": o.LogFile = Next(); break;
                default:
                    if (a.StartsWith('-')) throw new ArgumentException($"Неизвестный параметр {a}");
                    if (o.Host != null) throw new ArgumentException("Адрес моста указан дважды");
                    o.Host = a;
                    break;
            }
        }
        return o;
    }

    static int ParsePort(string s) =>
        int.TryParse(s, out int p) && p is > 0 and < 65536 ? p : throw new ArgumentException($"Неверный порт: {s}");
}

static class Program
{
    static int Main(string[] args)
    {
        if (args.Any(a => a is "-h" or "--help" or "/?"))
        {
            PrintUsage();
            return 0;
        }

        Options opt;
        try
        {
            opt = Options.Parse(args);
        }
        catch (ArgumentException ex)
        {
            Console.Error.WriteLine(ex.Message);
            PrintUsage();
            return 2;
        }

        if (Console.IsInputRedirected || Console.IsOutputRedirected)
        {
            Console.Error.WriteLine("Программу нужно запускать в окне консоли.");
            return 2;
        }

        Console.OutputEncoding = Encoding.UTF8;
        Console.TreatControlCAsInput = true;   // Ctrl+C обрабатываем сами: аккуратный выход

        return new App(opt).Run();
    }

    static void PrintUsage()
    {
        Console.WriteLine("""
            serbridge — консоль беспроводного моста UART (ESP32)

            Использование:
              serbridge [адрес] [параметры]

              адрес            IP или имя моста (например 192.168.1.50 или serbridge.local).
                               Без адреса мост ищется в локальной сети автоматически.
            Параметры:
              -p, --port N     порт данных (по умолчанию 2323)
                  --ctrl N     порт управления (2324)
                  --udp N      порт поиска (2325)
                  --meter N    порт измерений напряжения (2326)
                  --eol X      окончание отправляемой строки: lf (по умолчанию), crlf, cr, none
              -t, --time       метки времени у строк
              -l, --log ФАЙЛ   записывать сеанс в файл
              -h, --help       эта справка
            """);
    }
}
