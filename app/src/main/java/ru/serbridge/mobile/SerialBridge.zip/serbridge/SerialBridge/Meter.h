// Meter.h — 4 канала измерения напряжения на ADS1115 (часть прошивки SerialBridge)
//
// Схема: ВХ1, ВХ2 — делители 100к/100к (0…5 В), ВХ3, ВХ4 — 390к/100к (0…12 В),
//        ADS1115 на I2C: SDA = D21, SCL = D22, ADDR → GND (0x48), питание 3,3 В.
//
// Опрос без блокировки: запуск преобразования → возврат в loop() → чтение результата.
// Каждые 1/rate секунды на порт 2326 уходит строка со средним, минимумом и максимумом:
//   H adc=ADS1115 rate=5 on=1111 n1=ВХ1 n2=ВХ2 n3=ВХ3 n4=ВХ4      (заголовок)
//   V t=123456 1=4.98213:4.71002:4.99001 2=... 3=... 4=...          (измерения)
//   E noadc                                                         (модуль не найден)
//   T vcc=4.98 pwr=1 sense=1                                        (питание МК, см. SerialBridge.ino)
//
// Клиентов потока может быть до MAX_METER_CLIENTS, строки получают все.
// Команды (порт 2324 / USB): vch, vrate <Гц>, vname <n> <имя>, vk <n> <коэф. делителя>,
//                            vcal <n> <поправка>, vcalto <n> <вольт по мультиметру>,
//                            von <n>, voff <n>

#pragma once
#include <Wire.h>

#define I2C_SDA_PIN     21
#define I2C_SCL_PIN     22
#define ADS_ADDR        0x48
#define METER_PORT      2326
#define V_CHANNELS      4

// Конфигурация ADS1115: однократное измерение, вход AINx относительно GND,
// шкала ±4,096 В, 250 измерений/с, компаратор выключен
#define ADS_REG_CONV    0x00
#define ADS_REG_CFG     0x01
#define ADS_FSR         4.096f
#define ADS_CFG_BASE    (0x8000 | (1 << 9) | (1 << 8) | (5 << 5) | 0x03)
#define ADS_CONV_MS     5      // время преобразования при 250 SPS — 4 мс с запасом
#define ADS_TIMEOUT_MS  50
#define ADS_PROBE_MS    2000   // как часто искать модуль, если его нет
#define I2C_FREQ        100000 // 100 кГц: на макетке с подтяжками 10 кОм 400 кГц работает на грани
#define METER_STUCK_MS  5000   // поток измерений не уходит в сеть столько — закрыть соединение
#define MAX_METER_CLIENTS 3    // одновременных клиентов потока измерений

struct VChannel {
  String name;
  float k;          // коэффициент делителя: Uвх = U(AIN) · k
  float cal;        // поправка по мультиметру
  bool on;
  double sum;       // накопление за интервал отчёта
  uint32_t n;
  float mn, mx;
  float avg;        // среднее за прошлый интервал (для vcalto)
  bool avgValid;
};

static const float V_DEFAULT_K[V_CHANNELS] = {2.0f, 2.0f, 4.9f, 4.9f};   // (R1+R2)/R2

VChannel vch[V_CHANNELS];

enum AdsState : uint8_t { ADS_ABSENT, ADS_IDLE, ADS_CONVERTING };
AdsState adsState = ADS_ABSENT;
uint8_t adsCh = 0;
uint32_t adsStartMs = 0, adsProbeMs = 0;
bool adsProbed = false;
uint16_t adsSamples = 0;
bool adsNibbleSeen = false, adsIs1015 = false;
uint32_t adsErrCount = 0;      // сколько раз модуль переставал отвечать

uint16_t vIntervalMs = 200;    // 5 отчётов в секунду
uint32_t vReportMs = 0;

WiFiServer meterServer(METER_PORT);
bool meterHeaderPending = true; // заголовок изменился — разослать всем клиентам

struct MeterClient {
  WiFiClient c;
  bool used = false;
  bool headerPending = true;
  String out;                  // очередь строк на отправку (строки не режутся)
  uint32_t since = 0;
  uint32_t stuckSinceMs = 0;
};
MeterClient mcl[MAX_METER_CLIENTS];

int meterCount() {
  int n = 0;
  for (auto &m : mcl)
    if (m.used) n++;
  return n;
}

void meterDrop(MeterClient &m) {
  m.c.stop();
  m.used = false;
  m.out = "";
  m.stuckSinceMs = 0;
}

void meterStopAll() {
  for (auto &m : mcl)
    if (m.used) meterDrop(m);
}

// ---------------------------------------------------------------- I2C
bool adsWrite(uint8_t reg, uint16_t v) {
  Wire.beginTransmission(ADS_ADDR);
  Wire.write(reg);
  Wire.write((uint8_t)(v >> 8));
  Wire.write((uint8_t)(v & 0xFF));
  return Wire.endTransmission() == 0;
}

bool adsRead(uint8_t reg, uint16_t &v) {
  Wire.beginTransmission(ADS_ADDR);
  Wire.write(reg);
  if (Wire.endTransmission() != 0) return false;
  if (Wire.requestFrom((uint8_t)ADS_ADDR, (uint8_t)2) != 2) return false;
  uint8_t hi = Wire.read();
  uint8_t lo = Wire.read();
  v = ((uint16_t)hi << 8) | lo;
  return true;
}

const char *adcName() {
  if (adsState == ADS_ABSENT) return "none";
  return adsIs1015 ? "ADS1015" : "ADS1115";
}

void resetChannelStats(VChannel &c) {
  c.sum = 0;
  c.n = 0;
  c.avgValid = false;
}

// Восстановление шины I2C: если ведомый «завис» посреди байта и держит SDA в нуле,
// 9 тактов SCL выпускают его, затем условие STOP и повторная инициализация Wire.
void i2cBusRecover() {
  Wire.end();
  pinMode(I2C_SDA_PIN, INPUT_PULLUP);
  pinMode(I2C_SCL_PIN, INPUT_PULLUP);
  delayMicroseconds(10);
  for (int i = 0; i < 9 && digitalRead(I2C_SDA_PIN) == LOW; i++) {
    pinMode(I2C_SCL_PIN, OUTPUT);
    digitalWrite(I2C_SCL_PIN, LOW);
    delayMicroseconds(10);
    pinMode(I2C_SCL_PIN, INPUT_PULLUP);
    delayMicroseconds(10);
  }
  pinMode(I2C_SDA_PIN, OUTPUT);                         // STOP: SDA 0 → 1 при SCL = 1
  digitalWrite(I2C_SDA_PIN, LOW);
  delayMicroseconds(10);
  pinMode(I2C_SDA_PIN, INPUT_PULLUP);
  delayMicroseconds(10);
  Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN, (uint32_t)I2C_FREQ);
  Wire.setTimeOut(20);
}

void adsLost() {
  if (adsState != ADS_ABSENT) {
    adsErrCount++;
    LOG("ADS1115 не отвечает (раз: %lu) — восстанавливаю шину I2C", (unsigned long)adsErrCount);
  }
  i2cBusRecover();
  for (int i = 0; i < V_CHANNELS; i++) resetChannelStats(vch[i]);
  adsState = ADS_ABSENT;
  adsProbeMs = millis();
  meterHeaderPending = true;
}

// ---------------------------------------------------------------- настройки
void meterLoadConfig() {
  for (int i = 0; i < V_CHANNELS; i++) {
    char key[8];
    VChannel &c = vch[i];
    snprintf(key, sizeof(key), "vn%d", i + 1);
    c.name = prefs.isKey(key) ? prefs.getString(key) : String("ВХ") + String(i + 1);
    snprintf(key, sizeof(key), "vk%d", i + 1);
    c.k = prefs.isKey(key) ? prefs.getFloat(key) : V_DEFAULT_K[i];
    snprintf(key, sizeof(key), "vc%d", i + 1);
    c.cal = prefs.isKey(key) ? prefs.getFloat(key) : 1.0f;
    snprintf(key, sizeof(key), "ve%d", i + 1);
    c.on = prefs.isKey(key) ? prefs.getBool(key) : true;
    c.sum = 0;
    c.n = 0;
    c.avgValid = false;
  }
  if (prefs.isKey("vrate")) vIntervalMs = prefs.getUShort("vrate");
  if (vIntervalMs < 50 || vIntervalMs > 1000) vIntervalMs = 200;
}

// ---------------------------------------------------------------- опрос АЦП
void adsTick() {
  uint32_t now = millis();
  switch (adsState) {
    case ADS_ABSENT: {
      if (adsProbed && now - adsProbeMs < ADS_PROBE_MS) return;
      adsProbed = true;
      adsProbeMs = now;
      Wire.beginTransmission(ADS_ADDR);
      if (Wire.endTransmission() != 0) {
        i2cBusRecover();                                // шина могла остаться занятой
        return;
      }
      {
        adsState = ADS_IDLE;
        adsSamples = 0;
        adsNibbleSeen = false;
        adsIs1015 = false;
        meterHeaderPending = true;
        LOG("ADS1115 найден, адрес 0x%02X", ADS_ADDR);
      }
      return;
    }

    case ADS_IDLE: {
      for (int i = 0; i < V_CHANNELS && !vch[adsCh].on; i++) adsCh = (adsCh + 1) % V_CHANNELS;
      if (!vch[adsCh].on) return;                       // все каналы выключены
      uint16_t cfg = ADS_CFG_BASE | ((uint16_t)(4 + adsCh) << 12);
      if (!adsWrite(ADS_REG_CFG, cfg)) {
        adsLost();
        return;
      }
      adsStartMs = now;
      adsState = ADS_CONVERTING;
      return;
    }

    case ADS_CONVERTING: {
      if (now - adsStartMs < ADS_CONV_MS) return;
      uint16_t cfg;
      if (!adsRead(ADS_REG_CFG, cfg)) {
        adsLost();
        return;
      }
      if (!(cfg & 0x8000)) {                            // ещё измеряет
        if (now - adsStartMs > ADS_TIMEOUT_MS) adsLost();
        return;
      }
      uint16_t raw;
      if (!adsRead(ADS_REG_CONV, raw)) {
        adsLost();
        return;
      }
      int16_t s = (int16_t)raw;

      // Перемаркированный ADS1015 (12 бит): младшие 4 бита всегда нули
      if (!adsIs1015 && !adsNibbleSeen && s > 200) {
        if (raw & 0x000F) adsNibbleSeen = true;
        else if (++adsSamples >= 200) {
          adsIs1015 = true;
          meterHeaderPending = true;
          LOG("Похоже, это ADS1015 (12 бит), а не ADS1115");
        }
      }

      VChannel &c = vch[adsCh];
      float v = s * (ADS_FSR / 32768.0f) * c.k * c.cal;
      c.sum += v;
      c.n++;
      if (c.n == 1 || v < c.mn) c.mn = v;
      if (c.n == 1 || v > c.mx) c.mx = v;

      adsCh = (adsCh + 1) % V_CHANNELS;
      adsState = ADS_IDLE;
      return;
    }
  }
}

// ---------------------------------------------------------------- поток измерений
bool meterQueueTo(MeterClient &m, const String &line) {
  if (m.out.length() > 2048) return false;             // сеть не успевает — пропускаем отчёт целиком
  m.out += line;
  m.out += "\n";
  return true;
}

void meterQueue(const String &line) {                   // всем клиентам
  for (auto &m : mcl)
    if (m.used) meterQueueTo(m, line);
}

String meterHeader() {
  String h = "H adc=";
  h += adcName();
  h += " rate=" + String(1000 / vIntervalMs) + " err=" + String(adsErrCount) + " on=";
  for (int i = 0; i < V_CHANNELS; i++) h += vch[i].on ? '1' : '0';
  for (int i = 0; i < V_CHANNELS; i++) h += " n" + String(i + 1) + "=" + vch[i].name;
  return h;
}

void meterTick() {
  while (meterServer.hasClient()) {
    WiFiClient c = meterServer.accept();
    if (!c) break;
    MeterClient *slot = nullptr;
    for (auto &m : mcl)
      if (!m.used) { slot = &m; break; }
    if (!slot) {                                        // мест нет — кого вытеснить, как у потока данных:
      IPAddress ip = c.remoteIP();                      // тот же адрес → копится очередь → самое старое
      for (auto &m : mcl)
        if (m.used && m.c.remoteIP() == ip && (!slot || m.since - slot->since > 0x80000000UL)) slot = &m;
      if (!slot)
        for (auto &m : mcl)
          if (m.used && m.out.length() >= 512 && (!slot || m.out.length() > slot->out.length())) slot = &m;
      if (!slot) {
        slot = &mcl[0];
        for (auto &m : mcl)
          if (m.since - slot->since > 0x80000000UL) slot = &m;
      }
      meterDrop(*slot);
    }
    slot->c = c;
    slot->used = true;
    slot->since = millis();
    slot->out = "";
    slot->headerPending = true;
    slot->stuckSinceMs = 0;
    slot->c.setNoDelay(true);
    setKeepAlive(slot->c);
  }
  for (auto &m : mcl)
    if (m.used && !clientAlive(m.c)) meterDrop(m);

  uint32_t now = millis();
  if (now - vReportMs >= vIntervalMs) {
    vReportMs = now;
    if (meterHeaderPending) {
      for (auto &m : mcl) m.headerPending = true;
      meterHeaderPending = false;
    }
    String header;
    for (auto &m : mcl) {
      if (!m.used || !m.headerPending) continue;
      if (header.length() == 0) header = meterHeader();
      if (meterQueueTo(m, header)) m.headerPending = false;
    }
    meterQueue(targetLine());
    if (adsState == ADS_ABSENT) {
      meterQueue("E noadc");                            // каждый отчёт: консоль сразу видит причину
    } else {
      char b[48];
      String line = "V t=" + String(now);
      for (int i = 0; i < V_CHANNELS; i++) {
        VChannel &c = vch[i];
        if (!c.on || c.n == 0) continue;
        c.avg = (float)(c.sum / c.n);
        c.avgValid = true;
        snprintf(b, sizeof(b), " %d=%.5f:%.5f:%.5f", i + 1, c.avg, c.mn, c.mx);
        line += b;
        c.sum = 0;
        c.n = 0;
      }
      meterQueue(line);
    }
  }

  // Неблокирующая отправка очередей
  for (auto &m : mcl) {
    if (!m.used || m.out.length() == 0) continue;
    int w = send(m.c.fd(), m.out.c_str(), m.out.length(), MSG_DONTWAIT);
    if (w > 0) {
      m.out.remove(0, w);
      m.stuckSinceMs = 0;
    } else if (w < 0 && errno != EAGAIN && errno != EWOULDBLOCK) {
      meterDrop(m);
    } else if (m.stuckSinceMs == 0) {
      m.stuckSinceMs = now ? now : 1;
    } else if (now - m.stuckSinceMs > METER_STUCK_MS) {
      // Соединение «повисло»: данные не уходят, а keepalive при неотправленных данных молчит.
      // Закрываем — клиент переподключится сам.
      LOG("Поток измерений не уходит %lu мс — соединение закрыто", (unsigned long)(now - m.stuckSinceMs));
      meterDrop(m);
    }
  }
}

// ---------------------------------------------------------------- команды
// "2 текст" → номер канала 0..3 и остаток; -1 при ошибке
int parseChannel(const String &arg, String &rest) {
  int sp = arg.indexOf(' ');
  String num = sp < 0 ? arg : arg.substring(0, sp);
  rest = sp < 0 ? String("") : arg.substring(sp + 1);
  rest.trim();
  int n = num.toInt();
  return (n >= 1 && n <= V_CHANNELS) ? n - 1 : -1;
}

float parseFloatArg(String s, bool &ok) {
  s.replace(',', '.');
  char *end = nullptr;
  float f = strtof(s.c_str(), &end);
  ok = s.length() > 0 && end != nullptr && *end == '\0';
  return f;
}

void saveChannel(int i) {
  char key[8];
  snprintf(key, sizeof(key), "vn%d", i + 1);
  prefs.putString(key, vch[i].name);
  snprintf(key, sizeof(key), "vk%d", i + 1);
  prefs.putFloat(key, vch[i].k);
  snprintf(key, sizeof(key), "vc%d", i + 1);
  prefs.putFloat(key, vch[i].cal);
  snprintf(key, sizeof(key), "ve%d", i + 1);
  prefs.putBool(key, vch[i].on);
  resetChannelStats(vch[i]);                           // среднее со старыми настройками больше не годится
  meterHeaderPending = true;
}

// true — команда относится к измерениям, ответ в reply
bool meterCommand(const String &cmd, const String &arg, String &reply) {
  if (cmd == "vch") {
    char b[96];
    reply = "OK adc=" + String(adcName()) + " rate=" + String(1000 / vIntervalMs) + " err=" + String(adsErrCount);
    for (int i = 0; i < V_CHANNELS; i++) {
      snprintf(b, sizeof(b), " | %d %s k=%.4f cal=%.4f %s", i + 1, vch[i].name.c_str(),
               vch[i].k, vch[i].cal, vch[i].on ? "on" : "off");
      reply += b;
    }
    return true;
  }

  if (cmd == "vrate") {
    int hz = arg.toInt();
    if (hz < 1 || hz > 20) {
      reply = "ERR частота от 1 до 20 Гц";
      return true;
    }
    vIntervalMs = 1000 / hz;
    prefs.putUShort("vrate", vIntervalMs);
    meterHeaderPending = true;
    reply = "OK rate=" + String(hz);
    return true;
  }

  if (cmd != "vname" && cmd != "vk" && cmd != "vcal" && cmd != "vcalto" &&
      cmd != "von" && cmd != "voff") return false;

  String rest;
  int i = parseChannel(arg, rest);
  if (i < 0) {
    reply = "ERR номер канала 1…" + String(V_CHANNELS);
    return true;
  }
  VChannel &c = vch[i];
  bool ok = true;

  if (cmd == "von" || cmd == "voff") {
    c.on = (cmd == "von");
  } else if (cmd == "vname") {
    if (rest.length() == 0 || rest.length() > 24 || rest.indexOf(' ') >= 0) {
      reply = "ERR имя без пробелов, до 12 символов";
      return true;
    }
    c.name = rest;
  } else if (cmd == "vk") {
    float k = parseFloatArg(rest, ok);
    if (!ok || !(k >= 0.1f && k <= 100.0f)) {
      reply = "ERR коэффициент делителя от 0.1 до 100";
      return true;
    }
    c.k = k;
  } else if (cmd == "vcal") {
    float f = parseFloatArg(rest, ok);
    if (!ok || !(f >= 0.5f && f <= 2.0f)) {
      reply = "ERR поправка от 0.5 до 2";
      return true;
    }
    c.cal = f;
  } else {  // vcalto
    float target = parseFloatArg(rest, ok);
    if (!ok || !(target > 0.0f && target < 100.0f)) {
      reply = "ERR укажите напряжение по мультиметру, например vcalto 1 4.98";
      return true;
    }
    if (!c.avgValid || !(c.avg >= 0.05f)) {
      reply = "ERR на канале нет напряжения для калибровки";
      return true;
    }
    float f = c.cal * target / c.avg;
    if (!(f >= 0.5f && f <= 2.0f)) {
      reply = "ERR поправка вышла бы " + String(f, 3) + " — проверьте делитель";
      return true;
    }
    c.cal = f;
  }

  saveChannel(i);
  char b[96];
  snprintf(b, sizeof(b), "OK %d %s k=%.4f cal=%.4f %s", i + 1, c.name.c_str(), c.k, c.cal,
           c.on ? "on" : "off");
  reply = b;
  return true;
}

// ---------------------------------------------------------------- запуск
void meterSetup() {
  meterLoadConfig();
  Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN, (uint32_t)I2C_FREQ);
  Wire.setTimeOut(20);
  meterServer.begin();
  meterServer.setNoDelay(true);
}

void meterLoop() {
  adsTick();
  meterTick();
}
