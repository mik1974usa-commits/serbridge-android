// ===================== Второй приёмник: линия AUX как вход UART1 =====================
// XP2.6 → HV4/LV4 модуля уровней → D18 → RX UART1. Только приём: к XP2.6 подключают выход TX
// стороннего устройства (радар LD2410C, GPS, второй UART отлаживаемого МК…). Байты отдаются
// без изменений всем клиентам порта AUX_PORT (2327/TCP). Включается командой «aux uart <бод>»,
// выключается «aux off»; режим сохраняется в NVS и восстанавливается после перезагрузки.
// Пока приёмник включён, команды aux 0 / aux 1 / aux pulse недоступны: D18 занят UART1.
//
// Уровни: сторона HV модуля питается от XP2.3 (Vcc МК), поэтому без питания МК канал не работает.

#define AUX_PORT          2327
#define MAX_AUX_CLIENTS   3
#define AUX_HIST_SIZE     8192           // байт, степень двойки
#define AUX_FLUSH_SIZE    512            // отправлять, когда накопилось столько...
#define AUX_FLUSH_MAX_MS  20             // ...или данные ждут дольше этого, или линия замолчала

HardwareSerial &AuxSer = Serial1;

struct AuxClient {
  WiFiClient c;
  bool used = false;
  uint32_t pos = 0;                      // позиция чтения в auxHist
  uint32_t lost = 0;
  uint32_t since = 0;
};
AuxClient acl[MAX_AUX_CLIENTS];
int auxCount = 0;
WiFiServer auxServer(AUX_PORT);

static_assert((AUX_HIST_SIZE & (AUX_HIST_SIZE - 1)) == 0, "AUX_HIST_SIZE — степень двойки");
uint8_t auxHist[AUX_HIST_SIZE];
uint32_t auxHead = 0;                    // сквозной счётчик принятых байт (см. hist в основном файле)

uint32_t auxBaud = 0;                    // 0 — приёмник выключен
uint32_t auxRxBytes = 0, auxLastRxUs = 0, auxPendSinceMs = 0, auxIdleUs = 2000;
bool auxForce = false;
volatile uint32_t auxErrFrame = 0;       // ошибки кадра/чётности/обрыв линии
volatile uint32_t auxErrOvf = 0;         // переполнение FIFO/буфера UART

// Счётчик ошибок приёма есть в ядре ESP32 начиная с 2.0.3
#if defined(ESP_ARDUINO_VERSION_MAJOR) && \
    (ESP_ARDUINO_VERSION_MAJOR > 2 || \
     (ESP_ARDUINO_VERSION_MAJOR == 2 && (ESP_ARDUINO_VERSION_MINOR > 0 || ESP_ARDUINO_VERSION_PATCH >= 3)))
#define AUX_HAVE_ERR_CB 1
#endif

bool auxUartActive() { return auxBaud != 0; }

void auxUartStart(uint32_t baud) {
  if (auxBaud) AuxSer.end();
  AuxSer.setRxBufferSize(2048);          // до begin()
  // TX не назначаем (-1): мост только слушает, D18 — вход
  AuxSer.begin(baud, SERIAL_8N1, TARGET_AUX_PIN, -1);
#ifdef AUX_HAVE_ERR_CB
  // После begin(): так ядро 2.0.x и 3.x гарантированно запускают задачу событий UART,
  // из которой вызывается обработчик (он работает в другой задаче — только счётчики)
  AuxSer.onReceiveError([](hardwareSerial_error_t e) {
    if (e == UART_BUFFER_FULL_ERROR || e == UART_FIFO_OVF_ERROR) auxErrOvf = auxErrOvf + 1;
    else if (e != UART_NO_ERROR) auxErrFrame = auxErrFrame + 1;
  });
#endif
  auxLow = false;
  auxPulseUntilMs = 0;
  auxBaud = baud;
  // «Линия замолчала» — пауза в 3 символа (30 бит), но не меньше 2 мс: так кадр устройства
  // (у LD2410 — 23 байта) уходит в сеть одним куском и клиенту проще его разобрать
  uint32_t idle = (uint32_t)(30000000ULL / baud);
  auxIdleUs = idle < 2000 ? 2000 : idle;
  auxErrFrame = 0;
  auxErrOvf = 0;
  auxRxBytes = 0;
  LOG("AUX: приём UART1 на D18, %lu бод, порт %d", (unsigned long)baud, AUX_PORT);
}

void auxUartStop() {
  if (!auxBaud) return;
  AuxSer.end();
  auxBaud = 0;
  auxRelease();                          // D18 — снова обычный вход
  LOG("AUX: приём выключен, линия снова для aux 0/1/pulse");
}

void auxDrop(AuxClient &a, const char *why) {
  if (!a.used) return;
  String ip = a.c.remoteIP().toString();
  a.c.stop();
  a.used = false;
  auxCount--;
  LOG("AUX-клиент %s: %s (осталось: %d)", ip.c_str(), why, auxCount);
}

uint32_t auxPending(const AuxClient &a) {
  uint32_t p = auxHead - a.pos;
  return p > AUX_HIST_SIZE ? AUX_HIST_SIZE : p;
}

// Кого вытеснить: прежнее соединение с того же адреса → отстающего → самого старого
AuxClient *auxVictim(IPAddress ip) {
  AuxClient *v = nullptr;
  for (auto &a : acl)
    if (a.used && a.c.remoteIP() == ip && (!v || a.since - v->since > 0x80000000UL)) v = &a;
  if (v) return v;
  for (auto &a : acl)
    if (a.used && auxPending(a) >= 2048 && (!v || auxPending(a) > auxPending(*v))) v = &a;
  if (v) return v;
  v = &acl[0];
  for (auto &a : acl)
    if (a.since - v->since > 0x80000000UL) v = &a;
  return v;
}

void auxAccept() {
  while (auxServer.hasClient()) {
    WiFiClient c = auxServer.accept();
    if (!c) break;
    AuxClient *slot = nullptr;
    for (auto &a : acl)
      if (!a.used) { slot = &a; break; }
    if (!slot) {
      slot = auxVictim(c.remoteIP());
      auxDrop(*slot, "вытеснен новым клиентом");
    }
    slot->c = c;
    slot->used = true;
    slot->since = millis();
    slot->pos = auxHead;                 // данные — с момента подключения
    slot->lost = 0;
    auxCount++;
    slot->c.setNoDelay(true);
    setKeepAlive(slot->c);
    LOG("AUX-клиент %s подключён (всего: %d)", slot->c.remoteIP().toString().c_str(), auxCount);
  }
  for (auto &a : acl)
    if (a.used && !clientAlive(a.c)) auxDrop(a, "отключился");
}

void auxLoop() {
  auxAccept();

  // Клиенты ничего не передают; если что-то прислали — читаем и отбрасываем
  static uint8_t junk[64];
  for (auto &a : acl)
    if (a.used && a.c.available() > 0) a.c.read(junk, sizeof(junk));

  if (!auxBaud) return;

  static uint8_t buf[256];
  int avail;
  while ((avail = AuxSer.available()) > 0) {
    size_t n = AuxSer.read(buf, (size_t)avail < sizeof(buf) ? (size_t)avail : sizeof(buf));
    if (n == 0) break;
    if (auxCount == 0) {                 // никто не слушает — только считаем
      auxRxBytes += n;
      continue;
    }
    bool wasEmpty = true;
    for (auto &a : acl)
      if (a.used && a.pos != auxHead) wasEmpty = false;
    if (wasEmpty) auxPendSinceMs = millis();
    for (size_t i = 0; i < n; i++) auxHist[(auxHead + i) & (AUX_HIST_SIZE - 1)] = buf[i];
    auxHead += n;
    auxRxBytes += n;
    auxLastRxUs = micros();
  }

  if (auxCount == 0) return;
  uint32_t pend = 0;
  for (auto &a : acl)
    if (a.used && auxPending(a) > pend) pend = auxPending(a);
  if (pend == 0) return;

  bool idle = (uint32_t)(micros() - auxLastRxUs) >= auxIdleUs;
  bool big = pend >= AUX_FLUSH_SIZE;
  bool old = (uint32_t)(millis() - auxPendSinceMs) >= AUX_FLUSH_MAX_MS;
  if (!(idle || big || old || auxForce)) return;
  auxForce = false;

  bool left = false;
  for (auto &a : acl) {
    if (!a.used) continue;
    uint32_t behind = auxHead - a.pos;
    if (behind > AUX_HIST_SIZE) {
      a.lost += behind - AUX_HIST_SIZE;
      a.pos = auxHead - AUX_HIST_SIZE;
    }
    for (int i = 0; i < 2 && a.pos != auxHead; i++) {
      uint32_t off = a.pos & (AUX_HIST_SIZE - 1);
      uint32_t len = auxHead - a.pos;
      if (len > AUX_HIST_SIZE - off) len = AUX_HIST_SIZE - off;
      if (len > TCP_CHUNK) len = TCP_CHUNK;
      int w = send(a.c.fd(), &auxHist[off], len, MSG_DONTWAIT);
      if (w < 0) {
        if (errno == EAGAIN || errno == EWOULDBLOCK) break;
        auxDrop(a, "ошибка передачи — соединение закрыто");
        break;
      }
      if (w == 0) break;
      a.pos += (uint32_t)w;
    }
    if (a.used && a.pos != auxHead) left = true;
  }
  if (left) auxForce = true;
  else auxPendSinceMs = millis();
}

void auxSetup() {
  auxServer.begin();
  auxServer.setNoDelay(true);
  uint32_t b = prefs.isKey("auxbaud") ? prefs.getUInt("auxbaud") : 0;
  if (b >= 300 && b <= 2000000) auxUartStart(b);
}

void auxStopAll() {
  for (auto &a : acl)
    if (a.used) a.c.stop();
}

uint32_t auxLostMax() {
  uint32_t m = 0;
  for (auto &a : acl)
    if (a.used && a.lost > m) m = a.lost;
  return m;
}

// Ответ на «aux …», когда речь о приёмнике; false — команда не про приёмник
bool auxUartCommand(const String &argIn, String &reply) {
  String arg = argIn;
  arg.toLowerCase();
  if (arg == "off") {
    if (!auxBaud) {
      reply = "OK приёмник AUX и так выключен";
      return true;
    }
    auxUartStop();
    prefs.putUInt("auxbaud", 0);
    reply = "OK приём на AUX выключен";
    return true;
  }
  if (arg.startsWith("uart")) {
    String a = arg.substring(4);
    a.trim();
    if (a.length() == 0) {
      reply = auxBaud ? "OK aux=uart baud=" + String(auxBaud) + " port=" + String(AUX_PORT)
                      : String("OK приёмник AUX выключен; включить: aux uart <бод>, например aux uart 256000");
      return true;
    }
    uint32_t b = strtoul(a.c_str(), nullptr, 10);
    if (b < 300 || b > 2000000) {
      reply = "ERR скорость должна быть от 300 до 2000000";
      return true;
    }
    auxUartStart(b);
    prefs.putUInt("auxbaud", b);
    reply = "OK приём на AUX (XP2.6): " + String(b) + " бод, поток — порт " + String(AUX_PORT);
    return true;
  }
  if (auxBaud && arg.length() > 0) {    // aux 0 / 1 / pulse при включённом приёмнике
    reply = "ERR линия AUX занята приёмом UART (" + String(auxBaud) + " бод); освободить — aux off";
    return true;
  }
  if (auxBaud) {                         // просто «aux»
    char b[160];
    snprintf(b, sizeof(b), "OK aux=uart baud=%lu port=%d rx=%lu err=%lu ovf=%lu clients=%d line=%d",
             (unsigned long)auxBaud, AUX_PORT, (unsigned long)auxRxBytes, (unsigned long)auxErrFrame,
             (unsigned long)auxErrOvf, auxCount, digitalRead(TARGET_AUX_PIN));
    reply = b;
    return true;
  }
  return false;
}
